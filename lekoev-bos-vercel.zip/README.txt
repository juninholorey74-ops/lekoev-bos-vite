DEPLOYMENT STEPS

1. Extract the ZIP
2. Upload folder to GitHub
3. Import repository into Vercel
4. Framework preset: Vite
5. Build command: npm run build
6. Output folder: dist

Local testing:
npm install
npm run dev
