import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
  createContext,
  useContext
} from "react";



/*
██╗     ███████╗██╗  ██╗ ██████╗ ███████╗██╗   ██╗    ██████╗  ██████╗ ███████╗
██║     ██╔════╝██║ ██╔╝██╔═══██╗██╔════╝██║   ██║    ██╔══██╗██╔═══██╗██╔════╝
██║     █████╗  █████╔╝ ██║   ██║█████╗  ██║   ██║    ██████╔╝██║   ██║███████╗
██║     ██╔══╝  ██╔═██╗ ██║   ██║██╔══╝  ╚██╗ ██╔╝    ██╔══██╗██║   ██║╚════██║
███████╗███████╗██║  ██╗╚██████╔╝███████╗ ╚████╔╝     ██████╔╝╚██████╔╝███████║
╚══════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝  ╚═══╝      ╚═════╝  ╚═════╝ ╚══════╝
Business Operating System  v4.0  |  Creator: Likafi Jr  |  © 2026 All Rights Reserved
*/

// ─────────────────────────────────────────────────────────────────────────────
// SOUND ENGINE
// ─────────────────────────────────────────────────────────────────────────────
let _AC = null;
const getAC = () => {
if (!_AC && typeof window !== "undefined") {
try { _AC = new (window.AudioContext || window.webkitAudioContext)(); } catch {}
}
return _AC;
};
const tone = (freq, dur, type = "sine", vol = 0.1, delay = 0) => {
try {
const c = getAC(); if (!c) return;
const o = c.createOscillator(), g = c.createGain();
o.connect(g); g.connect(c.destination);
o.frequency.value = freq; o.type = type;
const t = c.currentTime + delay;
g.gain.setValueAtTime(0, t);
g.gain.linearRampToValueAtTime(vol, t + 0.02);
g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
o.start(t); o.stop(t + dur + 0.05);
} catch {}
};
const SFX = {
tap:     () => tone(660, 0.06, "sine", 0.08),
success: () => { tone(523, 0.09, "sine", 0.1); tone(659, 0.11, "sine", 0.1, 0.1); tone(784, 0.16, "sine", 0.1, 0.2); },
error:   () => { tone(220, 0.12, "square", 0.08); tone(180, 0.16, "square", 0.08, 0.13); },
notify:  () => { tone(880, 0.08, "sine", 0.08); tone(1100, 0.1, "sine", 0.08, 0.1); },
coin:    () => { tone(1318, 0.04, "square", 0.07); tone(1760, 0.13, "sine", 0.08, 0.04); },
whoosh:  () => { for (let i = 0; i < 5; i++) tone(300 + i * 100, 0.04, "sine", 0.05, i * 0.03); },
welcome: () => { [523, 659, 784, 1047, 1318].forEach((f, i) => tone(f, 0.15, "sine", 0.08, i * 0.11)); },
upgrade: () => { [261, 329, 392, 523, 659, 784].forEach((f, i) => tone(f, 0.12, "sine", 0.09, i * 0.08)); },
};

// ─────────────────────────────────────────────────────────────────────────────
// THEMES - 7 premium, every var tested for contrast
// ─────────────────────────────────────────────────────────────────────────────
const THEMES = {
void:    { n:"Void",    g:"◼", bg:"#030409", p:"#07081a", c:"#0c0d22", cH:"#111432", b:"rgba(120,120,255,.06)", bH:"rgba(120,120,255,.13)", t1:"#eeeeff", t2:"#7070aa", t3:"#2e2e55", ac:"#6c6fff", ar:"108,111,255", ac2:"#ff6cd4", ok:"#3ddfa0", er:"#ff5c7c", wn:"#ffba3d" },
aurora:  { n:"Aurora",  g:"✦",  bg:"#020b06", p:"#050f09", c:"#091610", cH:"#0e1e15", b:"rgba(61,223,160,.06)", bH:"rgba(61,223,160,.13)", t1:"#d8f5e8", t2:"#4d9a72", t3:"#1a4030", ac:"#3ddfa0", ar:"61,223,160", ac2:"#7bffcc", ok:"#3ddfa0", er:"#ff5c7c", wn:"#ffba3d" },
ember:   { n:"Ember",   g:"◈",  bg:"#070200", p:"#0e0500", c:"#160900", cH:"#1c0d00", b:"rgba(255,130,50,.06)", bH:"rgba(255,130,50,.13)", t1:"#fff0d8", t2:"#a06030", t3:"#4a2008", ac:"#ff8232", ar:"255,130,50", ac2:"#ffcc50", ok:"#3ddfa0", er:"#ff5c7c", wn:"#ffba3d" },
royal:   { n:"Royal",   g:"♚",  bg:"#04020e", p:"#08051a", c:"#0d0b28", cH:"#131032", b:"rgba(150,90,255,.07)", bH:"rgba(150,90,255,.15)", t1:"#ece8ff", t2:"#8060cc", t3:"#3a2268", ac:"#9a5aff", ar:"154,90,255", ac2:"#ff5ac8", ok:"#3ddfa0", er:"#ff5c7c", wn:"#ffba3d" },
noir:    { n:"Noir",    g:"▪",  bg:"#080808", p:"#101010", c:"#181818", cH:"#202020", b:"rgba(255,255,255,.05)", bH:"rgba(255,255,255,.09)", t1:"#ededed", t2:"#808080", t3:"#383838", ac:"#e0ff5a", ar:"224,255,90", ac2:"#ff5ab4", ok:"#3ddfa0", er:"#ff5c7c", wn:"#ffba3d" },
ice:     { n:"Ice",     g:"❄",  bg:"#f2f5fc", p:"#e8edf7", c:"#ffffff", cH:"#f4f6ff", b:"rgba(0,0,0,.07)", bH:"rgba(0,0,0,.12)", t1:"#0f1228", t2:"#505878", t3:"#aab0cc", ac:"#3650ff", ar:"54,80,255", ac2:"#9036ff", ok:"#0ec47a", er:"#e02848", wn:"#e88a00" },
carbon:  { n:"Carbon",  g:"⬡",  bg:"#0a0c10", p:"#111418", c:"#191d24", cH:"#20252e", b:"rgba(200,210,230,.06)", bH:"rgba(200,210,230,.11)", t1:"#e8ecf4", t2:"#6878a0", t3:"#2a3050", ac:"#4a9eff", ar:"74,158,255", ac2:"#ff4a9e", ok:"#3ddfa0", er:"#ff5c7c", wn:"#ffba3d" },
};

const applyTheme = id => {
const t = THEMES[id] || THEMES.void;
const s = document.documentElement.style;
[["-bg",t.bg],["-p",t.p],["-c",t.c],["-cH",t.cH],["-b",t.b],["-bH",t.bH],
["-t1",t.t1],["-t2",t.t2],["-t3",t.t3],["-ac",t.ac],["-ar",t.ar],["-ac2",t.ac2],
["-ok",t.ok],["-er",t.er],["-wn",t.wn]].forEach(([k,v]) => s.setProperty(k,v));
};

// ─────────────────────────────────────────────────────────────────────────────
// i18n - 6 languages
// ─────────────────────────────────────────────────────────────────────────────
const LANG = {
en:{ hero:"The Business OS Built for Africa",sub:"Accounting · AI · Invoicing · Payroll · Inventory - one platform, your rules.",start:"Start Free Trial",signin:"Sign In",pricing:"Pricing",features:"Features",about:"About",dashboard:"Dashboard",transactions:"Transactions",clients:"Clients",reports:"Reports",ai:"AI Assistant",licenses:"Licenses",settings:"Settings",inventory:"Inventory",invoices:"Invoices",payroll:"Payroll",revenue:"Revenue",expenses:"Expenses",netProfit:"Net Profit",activeClients:"Active Clients",recentTxns:"Recent Transactions",viewAll:"View All",addNew:"+ Add",save:"Save",cancel:"Cancel",income:"Income",expense:"Expense",amount:"Amount",description:"Description",type:"Type",date:"Date",category:"Category",name:"Name",plan:"Plan",status:"Status",renewal:"Renewal",theme:"Theme",language:"Language",currency:"Currency",notifications:"Notifications",security:"Security",logout:"Sign Out",search:"Search...",generateLicense:"Generate License",revoke:"Revoke",extend:"Extend",tier:"Tier",maxDevices:"Max Devices",duration:"Duration",emailNotifs:"Email Notifications",smsAlerts:"SMS Alerts",twoFA:"Two-Factor Auth",autoBackup:"Auto Backup",saveChanges:"Save Changes",timezone:"Timezone",profitMargin:"Profit Margin",cashFlow:"Cash Flow",health:"Business Health",expBreakdown:"Expense Breakdown",askAI:"Ask AI",greet0:"Good morning",greet1:"Good afternoon",greet2:"Good evening",by:"Created by Likafi Jr",copy:"© 2026 Lekoev Enterprises. All Rights Reserved.",noResults:"Nothing found",all:"All",mrr:"MRR",arr:"ARR",overdue:"Overdue",paid:"Paid",pending:"Pending",draft:"Draft",active:"Active",trial:"Trial",salary:"Salary",runPayroll:"Run Payroll",businessName:"Business Name",sounds:"Sounds",animations:"Animations",passkeyGen:"Passkey Generator",copyKey:"Copy",copied:"Copied!",generate:"Generate",devicesAllowed:"Devices",licenseType:"License Type",revokeKey:"Revoke",createBiz:"Create Business",choosePlan:"Choose Your Plan",free:"Free",mo:"/mo",getStarted:"Get Started",mostPopular:"Most Popular",enterprise:"Enterprise",custom:"Custom",contactUs:"Contact Us",trialDays:"14-day free trial",noCard:"No credit card required",allPlans:"All plans include",selectBiz:"Select Business Type",bizDetails:"Business Details",location:"Location & Currency",modules:"Select Modules",selectPlan:"Select Plan",launch:"Launch My Business",welcomeTo:"Welcome to",yourBiz:"Your Business is Ready",backToDash:"Go to Dashboard",passKeyPrompt:"Enter your passkey",demoKey:"Demo passkey",upgradeNow:"Upgrade Now",currentPlan:"Current Plan" },
fr:{ hero:"L'OS Business Conçu pour l'Afrique",sub:"Comptabilité · IA · Facturation · Paie · Inventaire - une plateforme, vos règles.",start:"Démarrer l'essai gratuit",signin:"Se connecter",pricing:"Tarifs",features:"Fonctionnalités",about:"À propos",dashboard:"Tableau de bord",transactions:"Transactions",clients:"Clients",reports:"Rapports",ai:"Assistant IA",licenses:"Licences",settings:"Paramètres",inventory:"Inventaire",invoices:"Factures",payroll:"Paie",revenue:"Revenus",expenses:"Dépenses",netProfit:"Bénéfice net",activeClients:"Clients actifs",recentTxns:"Transactions récentes",viewAll:"Voir tout",addNew:"+ Ajouter",save:"Enregistrer",cancel:"Annuler",income:"Revenu",expense:"Dépense",amount:"Montant",description:"Description",type:"Type",date:"Date",category:"Catégorie",name:"Nom",plan:"Plan",status:"Statut",renewal:"Renouvellement",theme:"Thème",language:"Langue",currency:"Devise",notifications:"Notifications",security:"Sécurité",logout:"Déconnexion",search:"Rechercher...",generateLicense:"Générer licence",revoke:"Révoquer",extend:"Prolonger",tier:"Niveau",maxDevices:"Appareils max",duration:"Durée",emailNotifs:"Notifs email",smsAlerts:"Alertes SMS",twoFA:"Auth 2FA",autoBackup:"Sauvegarde auto",saveChanges:"Sauvegarder",timezone:"Fuseau horaire",profitMargin:"Marge bénéficiaire",cashFlow:"Flux de trésorerie",health:"Santé entreprise",expBreakdown:"Répartition dépenses",askAI:"Demander IA",greet0:"Bonjour",greet1:"Bonne après-midi",greet2:"Bonsoir",by:"Créé par Likafi Jr",copy:"© 2026 Lekoev Enterprises. Tous droits réservés.",noResults:"Aucun résultat",all:"Tout",mrr:"RMR",arr:"RRA",overdue:"En retard",paid:"Payé",pending:"En attente",draft:"Brouillon",active:"Actif",trial:"Essai",salary:"Salaire",runPayroll:"Lancer la paie",businessName:"Nom entreprise",sounds:"Sons",animations:"Animations",passkeyGen:"Générateur de clés",copyKey:"Copier",copied:"Copié!",generate:"Générer",devicesAllowed:"Appareils",licenseType:"Type de licence",revokeKey:"Révoquer",createBiz:"Créer entreprise",choosePlan:"Choisir votre plan",free:"Gratuit",mo:"/mois",getStarted:"Commencer",mostPopular:"Plus populaire",enterprise:"Entreprise",custom:"Personnalisé",contactUs:"Nous contacter",trialDays:"Essai gratuit 14 jours",noCard:"Sans carte bancaire",allPlans:"Tous les plans incluent",selectBiz:"Type d'entreprise",bizDetails:"Détails entreprise",location:"Lieu & Devise",modules:"Sélectionner modules",selectPlan:"Sélectionner plan",launch:"Lancer mon entreprise",welcomeTo:"Bienvenue sur",yourBiz:"Votre entreprise est prête",backToDash:"Aller au tableau de bord",passKeyPrompt:"Entrez votre clé",demoKey:"Clé démo",upgradeNow:"Mettre à niveau",currentPlan:"Plan actuel" },
es:{ hero:"El OS Empresarial Construido para África",sub:"Contabilidad · IA · Facturación · Nómina · Inventario - una plataforma, tus reglas.",start:"Iniciar prueba gratuita",signin:"Iniciar sesión",pricing:"Precios",features:"Funciones",about:"Acerca de",dashboard:"Panel",transactions:"Transacciones",clients:"Clientes",reports:"Informes",ai:"Asistente IA",licenses:"Licencias",settings:"Ajustes",inventory:"Inventario",invoices:"Facturas",payroll:"Nómina",revenue:"Ingresos",expenses:"Gastos",netProfit:"Beneficio neto",activeClients:"Clientes activos",recentTxns:"Transacciones recientes",viewAll:"Ver todo",addNew:"+ Agregar",save:"Guardar",cancel:"Cancelar",income:"Ingreso",expense:"Gasto",amount:"Monto",description:"Descripción",type:"Tipo",date:"Fecha",category:"Categoría",name:"Nombre",plan:"Plan",status:"Estado",renewal:"Renovación",theme:"Tema",language:"Idioma",currency:"Moneda",notifications:"Notificaciones",security:"Seguridad",logout:"Cerrar sesión",search:"Buscar...",generateLicense:"Generar licencia",revoke:"Revocar",extend:"Extender",tier:"Nivel",maxDevices:"Dispositivos máx",duration:"Duración",emailNotifs:"Notif. email",smsAlerts:"Alertas SMS",twoFA:"Auth 2FA",autoBackup:"Copia auto",saveChanges:"Guardar cambios",timezone:"Zona horaria",profitMargin:"Margen",cashFlow:"Flujo de caja",health:"Salud empresarial",expBreakdown:"Desglose gastos",askAI:"Preguntar IA",greet0:"Buenos días",greet1:"Buenas tardes",greet2:"Buenas noches",by:"Creado por Likafi Jr",copy:"© 2026 Lekoev Enterprises. Todos los derechos.",noResults:"Sin resultados",all:"Todo",mrr:"IMR",arr:"IAR",overdue:"Vencido",paid:"Pagado",pending:"Pendiente",draft:"Borrador",active:"Activo",trial:"Prueba",salary:"Salario",runPayroll:"Ejecutar nómina",businessName:"Nombre empresa",sounds:"Sonidos",animations:"Animaciones",passkeyGen:"Generador de claves",copyKey:"Copiar",copied:"¡Copiado!",generate:"Generar",devicesAllowed:"Dispositivos",licenseType:"Tipo de licencia",revokeKey:"Revocar",createBiz:"Crear empresa",choosePlan:"Elegir tu plan",free:"Gratis",mo:"/mes",getStarted:"Comenzar",mostPopular:"Más popular",enterprise:"Empresa",custom:"Personalizado",contactUs:"Contactarnos",trialDays:"Prueba gratuita 14 días",noCard:"Sin tarjeta de crédito",allPlans:"Todos los planes incluyen",selectBiz:"Tipo de negocio",bizDetails:"Detalles del negocio",location:"Lugar y Moneda",modules:"Seleccionar módulos",selectPlan:"Seleccionar plan",launch:"Lanzar mi empresa",welcomeTo:"Bienvenido a",yourBiz:"Tu empresa está lista",backToDash:"Ir al panel",passKeyPrompt:"Ingresa tu clave",demoKey:"Clave demo",upgradeNow:"Actualizar ahora",currentPlan:"Plan actual" },
pt:{ hero:"O OS Empresarial Construído para África",sub:"Contabilidade · IA · Faturação · Folha · Inventário - uma plataforma, suas regras.",start:"Iniciar teste gratuito",signin:"Entrar",pricing:"Preços",features:"Recursos",about:"Sobre",dashboard:"Painel",transactions:"Transações",clients:"Clientes",reports:"Relatórios",ai:"Assistente IA",licenses:"Licenças",settings:"Configurações",inventory:"Inventário",invoices:"Faturas",payroll:"Folha de pagamento",revenue:"Receita",expenses:"Despesas",netProfit:"Lucro líquido",activeClients:"Clientes ativos",recentTxns:"Transações recentes",viewAll:"Ver tudo",addNew:"+ Adicionar",save:"Salvar",cancel:"Cancelar",income:"Receita",expense:"Despesa",amount:"Valor",description:"Descrição",type:"Tipo",date:"Data",category:"Categoria",name:"Nome",plan:"Plano",status:"Status",renewal:"Renovação",theme:"Tema",language:"Idioma",currency:"Moeda",notifications:"Notificações",security:"Segurança",logout:"Sair",search:"Pesquisar...",generateLicense:"Gerar licença",revoke:"Revogar",extend:"Estender",tier:"Nível",maxDevices:"Dispositivos máx",duration:"Duração",emailNotifs:"Notif. e-mail",smsAlerts:"Alertas SMS",twoFA:"Auth 2FA",autoBackup:"Backup auto",saveChanges:"Salvar alterações",timezone:"Fuso horário",profitMargin:"Margem de lucro",cashFlow:"Fluxo de caixa",health:"Saúde do negócio",expBreakdown:"Detalhamento despesas",askAI:"Perguntar IA",greet0:"Bom dia",greet1:"Boa tarde",greet2:"Boa noite",by:"Criado por Likafi Jr",copy:"© 2026 Lekoev Enterprises. Todos os direitos.",noResults:"Nenhum resultado",all:"Todos",mrr:"RMR",arr:"RRA",overdue:"Vencido",paid:"Pago",pending:"Pendente",draft:"Rascunho",active:"Ativo",trial:"Teste",salary:"Salário",runPayroll:"Executar folha",businessName:"Nome da empresa",sounds:"Sons",animations:"Animações",passkeyGen:"Gerador de chaves",copyKey:"Copiar",copied:"Copiado!",generate:"Gerar",devicesAllowed:"Dispositivos",licenseType:"Tipo de licença",revokeKey:"Revogar",createBiz:"Criar empresa",choosePlan:"Escolher plano",free:"Grátis",mo:"/mês",getStarted:"Começar",mostPopular:"Mais popular",enterprise:"Empresa",custom:"Personalizado",contactUs:"Fale conosco",trialDays:"Teste gratuito 14 dias",noCard:"Sem cartão de crédito",allPlans:"Todos os planos incluem",selectBiz:"Tipo de negócio",bizDetails:"Detalhes do negócio",location:"Local e Moeda",modules:"Selecionar módulos",selectPlan:"Selecionar plano",launch:"Lançar minha empresa",welcomeTo:"Bem-vindo ao",yourBiz:"Sua empresa está pronta",backToDash:"Ir ao painel",passKeyPrompt:"Digite sua chave",demoKey:"Chave demo",upgradeNow:"Atualizar agora",currentPlan:"Plano atual" },
sw:{ hero:"Mfumo wa Biashara Ulioundwa kwa Afrika",sub:"Uhasibu · AI · Bili · Mishahara · Hesabu - jukwaa moja, sheria zako.",start:"Anza Jaribio la Bure",signin:"Ingia",pricing:"Bei",features:"Vipengele",about:"Kuhusu",dashboard:"Dashibodi",transactions:"Miamala",clients:"Wateja",reports:"Ripoti",ai:"Msaidizi AI",licenses:"Leseni",settings:"Mipangilio",inventory:"Orodha mali",invoices:"Ankara",payroll:"Mishahara",revenue:"Mapato",expenses:"Matumizi",netProfit:"Faida halisi",activeClients:"Wateja hai",recentTxns:"Miamala ya hivi karibuni",viewAll:"Ona yote",addNew:"+ Ongeza",save:"Hifadhi",cancel:"Ghairi",income:"Mapato",expense:"Matumizi",amount:"Kiasi",description:"Maelezo",type:"Aina",date:"Tarehe",category:"Kategoria",name:"Jina",plan:"Mpango",status:"Hali",renewal:"Upya",theme:"Mandhari",language:"Lugha",currency:"Sarafu",notifications:"Arifa",security:"Usalama",logout:"Toka",search:"Tafuta...",generateLicense:"Tengeneza leseni",revoke:"Batilisha",extend:"Ongeza",tier:"Kiwango",maxDevices:"Vifaa",duration:"Muda",emailNotifs:"Arifa barua pepe",smsAlerts:"Tahadhari SMS",twoFA:"Uthibitishaji hatua 2",autoBackup:"Hifadhi otomatiki",saveChanges:"Hifadhi mabadiliko",timezone:"Saa za eneo",profitMargin:"Kiwango cha faida",cashFlow:"Mtiririko wa fedha",health:"Afya ya biashara",expBreakdown:"Mgawanyo matumizi",askAI:"Uliza AI",greet0:"Habari za asubuhi",greet1:"Habari za mchana",greet2:"Habari za jioni",by:"Imeundwa na Likafi Jr",copy:"© 2026 Lekoev Enterprises. Haki zote.",noResults:"Hakuna matokeo",all:"Yote",mrr:"MRR",arr:"ARR",overdue:"Imechelewa",paid:"Imelipwa",pending:"Inasubiri",draft:"Rasimu",active:"Inafanya kazi",trial:"Majaribio",salary:"Mshahara",runPayroll:"Tekeleza mishahara",businessName:"Jina la biashara",sounds:"Sauti",animations:"Michoro",passkeyGen:"Kizazi cha funguo",copyKey:"Nakili",copied:"Imenakiliwa!",generate:"Zalisha",devicesAllowed:"Vifaa",licenseType:"Aina ya leseni",revokeKey:"Batilisha",createBiz:"Unda biashara",choosePlan:"Chagua mpango wako",free:"Bure",mo:"/mwezi",getStarted:"Anza",mostPopular:"Maarufu zaidi",enterprise:"Shirika",custom:"Maalum",contactUs:"Wasiliana nasi",trialDays:"Jaribio la bure siku 14",noCard:"Bila kadi ya benki",allPlans:"Mipango yote inajumuisha",selectBiz:"Aina ya biashara",bizDetails:"Maelezo ya biashara",location:"Mahali & Sarafu",modules:"Chagua moduli",selectPlan:"Chagua mpango",launch:"Zindua biashara yangu",welcomeTo:"Karibu",yourBiz:"Biashara yako iko tayari",backToDash:"Nenda kwenye dashibodi",passKeyPrompt:"Ingiza funguo yako",demoKey:"Funguo ya demo",upgradeNow:"Boresha sasa",currentPlan:"Mpango wa sasa" },
de:{ hero:"Das Business-OS für Afrika",sub:"Buchhaltung · KI · Rechnungen · Lohn · Inventar - eine Plattform, Ihre Regeln.",start:"Kostenlose Testversion",signin:"Anmelden",pricing:"Preise",features:"Funktionen",about:"Über uns",dashboard:"Übersicht",transactions:"Transaktionen",clients:"Kunden",reports:"Berichte",ai:"KI-Assistent",licenses:"Lizenzen",settings:"Einstellungen",inventory:"Inventar",invoices:"Rechnungen",payroll:"Lohnabrechnung",revenue:"Einnahmen",expenses:"Ausgaben",netProfit:"Nettogewinn",activeClients:"Aktive Kunden",recentTxns:"Letzte Transaktionen",viewAll:"Alle anzeigen",addNew:"+ Hinzufügen",save:"Speichern",cancel:"Abbrechen",income:"Einnahme",expense:"Ausgabe",amount:"Betrag",description:"Beschreibung",type:"Typ",date:"Datum",category:"Kategorie",name:"Name",plan:"Plan",status:"Status",renewal:"Erneuerung",theme:"Thema",language:"Sprache",currency:"Währung",notifications:"Benachrichtigungen",security:"Sicherheit",logout:"Abmelden",search:"Suchen...",generateLicense:"Lizenz generieren",revoke:"Widerrufen",extend:"Verlängern",tier:"Stufe",maxDevices:"Max. Geräte",duration:"Laufzeit",emailNotifs:"E-Mail-Benachrichtigungen",smsAlerts:"SMS-Alarme",twoFA:"Zwei-Faktor-Auth",autoBackup:"Auto-Backup",saveChanges:"Änderungen speichern",timezone:"Zeitzone",profitMargin:"Gewinnmarge",cashFlow:"Cashflow",health:"Unternehmensgesundheit",expBreakdown:"Ausgabenaufschlüsselung",askAI:"KI fragen",greet0:"Guten Morgen",greet1:"Guten Nachmittag",greet2:"Guten Abend",by:"Erstellt von Likafi Jr",copy:"© 2026 Lekoev Enterprises. Alle Rechte vorbehalten.",noResults:"Keine Ergebnisse",all:"Alle",mrr:"MRR",arr:"ARR",overdue:"Überfällig",paid:"Bezahlt",pending:"Ausstehend",draft:"Entwurf",active:"Aktiv",trial:"Testphase",salary:"Gehalt",runPayroll:"Gehalt ausführen",businessName:"Unternehmensname",sounds:"Töne",animations:"Animationen",passkeyGen:"Schlüsselgenerator",copyKey:"Kopieren",copied:"Kopiert!",generate:"Generieren",devicesAllowed:"Geräte",licenseType:"Lizenztyp",revokeKey:"Widerrufen",createBiz:"Unternehmen erstellen",choosePlan:"Plan wählen",free:"Kostenlos",mo:"/Monat",getStarted:"Loslegen",mostPopular:"Beliebteste",enterprise:"Unternehmen",custom:"Individuell",contactUs:"Kontakt",trialDays:"14 Tage kostenlose Testversion",noCard:"Keine Kreditkarte erforderlich",allPlans:"Alle Pläne beinhalten",selectBiz:"Unternehmensart",bizDetails:"Unternehmensdetails",location:"Standort & Währung",modules:"Module auswählen",selectPlan:"Plan auswählen",launch:"Mein Unternehmen starten",welcomeTo:"Willkommen bei",yourBiz:"Ihr Unternehmen ist bereit",backToDash:"Zum Dashboard",passKeyPrompt:"Schlüssel eingeben",demoKey:"Demo-Schlüssel",upgradeNow:"Jetzt upgraden",currentPlan:"Aktueller Plan" },
};

const CURRENCIES = { XAF:{s:"FCFA",l:"fr-CM"}, USD:{s:"$",l:"en-US"}, EUR:{s:"€",l:"fr-FR"}, GBP:{s:"£",l:"en-GB"}, NGN:{s:"₦",l:"en-NG"}, GHS:{s:"₵",l:"en-GH"}, KES:{s:"KSh",l:"sw-KE"}, ZAR:{s:"R",l:"en-ZA"} };
const money = (v, c = "XAF") => { const cc = CURRENCIES[c]||CURRENCIES.XAF, n = Number(v)||0; if(n>=1e9) return cc.s+(n/1e9).toFixed(2)+"B"; if(n>=1e6) return cc.s+(n/1e6).toFixed(2)+"M"; if(n>=1000) return cc.s+(n/1000).toFixed(1)+"K"; return cc.s+n.toLocaleString(cc.l); };

// ─────────────────────────────────────────────────────────────────────────────
// SUBSCRIPTION PLANS
// ─────────────────────────────────────────────────────────────────────────────
const PLANS = [
{ id:"free",       label:"Starter",    price:0,     priceXAF:0,        color:"#3ddfa0", users:2,   modules:3, ai:false, support:"Community", badge:null,         period:"forever" },
{ id:"pro",        label:"Pro",        price:29,    priceXAF:17000,    color:"#6c6fff", users:15,  modules:99,ai:true,  support:"Priority",   badge:"Most Popular",period:"mo" },
{ id:"business",   label:"Business",   price:79,    priceXAF:47000,    color:"#ff8232", users:50,  modules:99,ai:true,  support:"24/7 Chat",  badge:null,         period:"mo" },
{ id:"enterprise", label:"Enterprise", price:null,  priceXAF:null,     color:"#9a5aff", users:999, modules:99,ai:true,  support:"Dedicated",  badge:"Best Value",  period:"custom" },
];

const PLAN_FEATURES = {
free:       ["2 team members","3 core modules","Basic reports","500 transactions/mo","Community support"],
pro:        ["15 team members","All modules","Advanced reports + AI","Unlimited transactions","AI Business Assistant","Priority support","Custom categories"],
business:   ["50 team members","All modules","Advanced analytics","Unlimited everything","AI + Voice commands","24/7 chat support","API access","Custom branding"],
enterprise: ["Unlimited members","Custom modules","Custom analytics","SLA guarantee","Dedicated AI model","Dedicated support","On-premise option","OHADA compliance","White-label"],
};

const ALL_FEATURES = ["Accounting & OHADA","Invoicing & Billing","Inventory Management","Payroll","Client CRM","AI Assistant","Multi-currency","6+ Languages","Mobile-first","Passkey Licensing"];

// ─────────────────────────────────────────────────────────────────────────────
// BUSINESS TYPES
// ─────────────────────────────────────────────────────────────────────────────
const BIZ_TYPES = [
{id:"technology",  icon:"💻", label:"Technology / Software"},
{id:"pharmacy",    icon:"💊", label:"Pharmacy / Healthcare"},
{id:"restaurant",  icon:"🍽", label:"Restaurant / Food"},
{id:"retail",      icon:"🛒", label:"Retail / Trading"},
{id:"brocante",    icon:"🏪", label:"Second-hand / Brocante"},
{id:"consulting",  icon:"📋", label:"Consulting / Services"},
{id:"manufacturing",icon:"🏭",label:"Manufacturing"},
{id:"agriculture", icon:"🌿", label:"Agriculture"},
{id:"education",   icon:"📚", label:"Education"},
{id:"construction",icon:"🏗", label:"Construction"},
{id:"transport",   icon:"🚛", label:"Transport / Logistics"},
{id:"other",       icon:"🏢", label:"Other Business"},
];

const MODULES_LIST = [
{id:"accounting",icon:"📊",label:"Accounting & Finance",desc:"OHADA-compliant ledger"},
{id:"invoicing", icon:"📄",label:"Invoicing & Billing",desc:"Create & send invoices"},
{id:"inventory", icon:"📦",label:"Inventory",desc:"Stock tracking & alerts"},
{id:"payroll",   icon:"💼",label:"Payroll",desc:"Salaries & payslips"},
{id:"crm",       icon:"👥",label:"Client CRM",desc:"Manage relationships"},
{id:"reports",   icon:"📈",label:"Analytics",desc:"Charts & insights"},
{id:"ai",        icon:"✦", label:"AI Assistant",desc:"Voice & text commands"},
{id:"pos",       icon:"🏪",label:"Point of Sale",desc:"Physical sales"},
];

// ─────────────────────────────────────────────────────────────────────────────
// PASSKEY GENERATOR
// ─────────────────────────────────────────────────────────────────────────────
const CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const rSeg = n => Array.from({length:n},()=>CHARS[Math.floor(Math.random()*CHARS.length)]).join("");
const makePasskey = (tier) => { const p={free:"FRE",pro:"PRO",business:"BIZ",enterprise:"ENT"}[tier]||"PRO"; return `LKV-${p}-${new Date().getFullYear()}-${rSeg(3)}-${rSeg(4)}`; };
const makeKeyObj = (tier,dur,devs,tenant="") => {
const months={"trial":0.5,"6M":6,"1Y":12,"2Y":24}[dur]||12;
const exp=new Date(); exp.setMonth(exp.getMonth()+months);
return { id:Date.now().toString(36)+rSeg(3), key:makePasskey(tier), tier, dur, devs, status:"active", created:new Date().toISOString(), expires:exp.toISOString(), activations:0, tenant };
};

// ─────────────────────────────────────────────────────────────────────────────
// CONTEXT
// ─────────────────────────────────────────────────────────────────────────────
const Ctx = createContext(null);
const useApp = () => useContext(Ctx);

// ─────────────────────────────────────────────────────────────────────────────
// GLOBAL CSS
// ─────────────────────────────────────────────────────────────────────────────
const GSTYLE = `
@import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,300;12..96,400;12..96,500;12..96,700;12..96,800&family=DM+Mono:wght@400;500&family=Instrument+Serif:ital@0;1&display=swap');

*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;overflow:hidden;-webkit-font-smoothing:antialiased}
body{font-family:'Bricolage Grotesque',sans-serif;font-size:14px;line-height:1.5;background:var(-bg);color:var(-t1);transition:background .4s,color .4s}
::-webkit-scrollbar{width:3px;height:3px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(-bH);border-radius:99px}
::-webkit-scrollbar-thumb:hover{background:var(-ac)}

input,select,textarea{
display:block;width:100%;background:var(-c);border:1.5px solid var(-bH);
color:var(-t1)!important;font-family:'Bricolage Grotesque',sans-serif;font-size:13px;
border-radius:10px;padding:10px 14px;outline:none;
transition:border-color .2s,box-shadow .2s,background .2s;
appearance:none;-webkit-appearance:none;
}
input::placeholder{color:var(-t3)!important}
input:focus,select:focus,textarea:focus{border-color:var(-ac);box-shadow:0 0 0 3px rgba(var(-ar),.14);background:var(-cH)}
select option{background:var(-p)!important;color:var(-t1)!important}
button{cursor:pointer;font-family:'Bricolage Grotesque',sans-serif;border:none;background:none;padding:0}
textarea{resize:vertical}

.mono{font-family:'DM Mono',monospace}
.serif{font-family:'Instrument Serif',serif}
.gtext{background:linear-gradient(135deg,var(-ac),var(-ac2));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.gtext2{background:linear-gradient(135deg,var(-ac2),var(-ac));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}

@keyframes fadeUp  {from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeIn  {from{opacity:0}to{opacity:1}}
@keyframes scaleIn {from{opacity:0;transform:scale(.92)}to{opacity:1;transform:scale(1)}}
@keyframes slideL  {from{opacity:0;transform:translateX(-14px)}to{opacity:1;transform:translateX(0)}}
@keyframes spin    {to{transform:rotate(360deg)}}
@keyframes pulse   {0%,100%{opacity:1}50%{opacity:.25}}
@keyframes barUp   {from{transform:scaleY(0);transform-origin:bottom}to{transform:scaleY(1);transform-origin:bottom}}
@keyframes floatY  {0%,100%{transform:translateY(0)}50%{transform:translateY(-9px)}}
@keyframes glowP   {0%,100%{box-shadow:0 0 18px rgba(var(-ar),.18)}50%{box-shadow:0 0 40px rgba(var(-ar),.42)}}
@keyframes bounce3 {0%,80%,100%{transform:scale(0)}40%{transform:scale(1)}}
@keyframes wIn     {from{opacity:0;transform:scale(.84)}to{opacity:1;transform:scale(1)}}
@keyframes pBar    {from{width:0%}to{width:100%}}
@keyframes confetti{0%{opacity:1;transform:translateY(0) rotate(0)}100%{opacity:0;transform:translateY(-90px) rotate(200deg)}}
@keyframes shimmer {0%{background-position:-600px 0}100%{background-position:600px 0}}
@keyframes marquee {0%{transform:translateX(0)}100%{transform:translateX(-50%)}}
@keyframes typeIn  {from{width:0}to{width:100%}}

.aFU  {animation:fadeUp .42s cubic-bezier(.22,1,.36,1) both}
.aFI  {animation:fadeIn .32s ease both}
.aSI  {animation:scaleIn .34s cubic-bezier(.22,1,.36,1) both}
.aSL  {animation:slideL .38s cubic-bezier(.22,1,.36,1) both}
.d1{animation-delay:.05s}.d2{animation-delay:.10s}.d3{animation-delay:.15s}
.d4{animation-delay:.20s}.d5{animation-delay:.25s}.d6{animation-delay:.30s}
.d7{animation-delay:.35s}.d8{animation-delay:.40s}

.chov{transition:transform .22s cubic-bezier(.22,1,.36,1),box-shadow .22s,border-color .22s}
.chov:hover{transform:translateY(-2px);box-shadow:0 14px 40px rgba(var(-ar),.14)!important;border-color:rgba(var(-ar),.28)!important}

@media(max-width:640px){
.mh{display:none!important}
.mg1{grid-template-columns:1fr!important}
.mg2{grid-template-columns:1fr 1fr!important}
.mwrap{flex-wrap:wrap!important}
}
`;

const GStyle = () => <style dangerouslySetInnerHTML={{__html:GSTYLE}} />;

// ─────────────────────────────────────────────────────────────────────────────
// ATOMS
// ─────────────────────────────────────────────────────────────────────────────
const Badge = ({c="def",sz="sm",children,style}) => {
const M = { def:{b:"var(-bH)",fg:"var(-t2)",bg:"rgba(255,255,255,.05)"}, ok:{b:"rgba(61,223,160,.22)",fg:"var(-ok)",bg:"rgba(61,223,160,.1)"}, er:{b:"rgba(255,92,124,.22)",fg:"var(-er)",bg:"rgba(255,92,124,.1)"}, wn:{b:"rgba(255,186,61,.22)",fg:"var(-wn)",bg:"rgba(255,186,61,.1)"}, ac:{b:"rgba(var(-ar),.25)",fg:"var(-ac)",bg:"rgba(var(-ar),.1)"}, gd:{b:"rgba(255,186,61,.3)",fg:"#ffba3d",bg:"rgba(255,186,61,.12)"}, pu:{b:"rgba(160,100,255,.3)",fg:"#a064ff",bg:"rgba(160,100,255,.12)"} };
const s = M[c]||M.def;
return <span style={{display:"inline-flex",alignItems:"center",gap:4,padding:sz==="xs"?"1px 7px":"3px 10px",borderRadius:99,fontSize:sz==="xs"?9.5:10.5,fontWeight:700,letterSpacing:".3px",whiteSpace:"nowrap",background:s.bg,color:s.fg,border:`1px solid ${s.b}`,...style}}>{children}</span>;
};

const Btn = ({children,onClick,v="pri",sz="md",disabled,full,style}) => {
const [h,setH] = useState(false);
const V = {
pri: {bg:"var(-ac)",fg:"var(-bg)",bd:"none",sh:h?"0 8px 24px rgba(var(-ar),.45)":"0 2px 10px rgba(var(-ar),.22)"},
gh:  {bg:h?"var(-c)":"transparent",fg:h?"var(-t1)":"var(-t2)",bd:"1px solid var(-b)",sh:"none"},
ol:  {bg:h?"rgba(var(-ar),.09)":"transparent",fg:"var(-ac)",bd:"1px solid rgba(var(-ar),.35)",sh:"none"},
er:  {bg:h?"rgba(255,92,124,.2)":"rgba(255,92,124,.09)",fg:"var(-er)",bd:"1px solid rgba(255,92,124,.3)",sh:"none"},
ok:  {bg:h?"rgba(61,223,160,.2)":"rgba(61,223,160,.09)",fg:"var(-ok)",bd:"1px solid rgba(61,223,160,.28)",sh:"none"},
sol: {bg:h?"var(-cH)":"var(-c)",fg:"var(-t1)",bd:"1px solid var(-bH)",sh:"none"},
wn:  {bg:h?"rgba(255,186,61,.2)":"rgba(255,186,61,.09)",fg:"var(-wn)",bd:"1px solid rgba(255,186,61,.3)",sh:"none"},
white:{bg:h?"rgba(255,255,255,.92)":"rgba(255,255,255,.85)",fg:"#0a0a14",bd:"none",sh:h?"0 8px 28px rgba(0,0,0,.3)":"0 2px 12px rgba(0,0,0,.15)"},
dark: {bg:h?"rgba(0,0,0,.85)":"rgba(0,0,0,.7)",fg:"#fff",bd:"1px solid rgba(255,255,255,.12)",sh:"none"},
}[v]||{};
const SZ = {xs:{p:"4px 10px",fs:11},sm:{p:"7px 14px",fs:12},md:{p:"10px 20px",fs:13},lg:{p:"13px 28px",fs:14},xl:{p:"16px 36px",fs:15}}[sz]||{};
return (
<button onClick={onClick} disabled={disabled}
onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)}
style={{padding:SZ.p,fontSize:SZ.fs,background:V.bg,color:V.fg,border:V.bd,borderRadius:10,fontWeight:700,display:"inline-flex",alignItems:"center",justifyContent:"center",gap:6,width:full?"100%":undefined,transition:"all .18s cubic-bezier(.22,1,.36,1)",boxShadow:V.sh,opacity:disabled?.4:1,cursor:disabled?"not-allowed":"pointer",transform:h&&!disabled?"translateY(-1px)":"none",...style}}>
{children}
</button>
);
};

const Card = ({children,style,glow,hov,className=""}) => {
const [h,setH] = useState(false);
return <div className={(hov?"chov ":"")+className} onMouseEnter={()=>hov&&setH(true)} onMouseLeave={()=>hov&&setH(false)} style={{background:"var(-c)",borderRadius:14,padding:"18px 20px",border:`1px solid ${glow||h?"rgba(var(--ar),.25)":"var(--b)"}`,boxShadow:glow?"0 0 30px rgba(var(-ar),.15)":"0 1px 8px rgba(0,0,0,.18)",transition:"all .22s cubic-bezier(.22,1,.36,1)",...style}}>{children}</div>;
};

const Spinner = ({size=15,color}) => <span style={{width:size,height:size,border:"2px solid rgba(255,255,255,.18)",borderTopColor:color||"currentColor",borderRadius:"50%",animation:"spin .65s linear infinite",display:"inline-block",flexShrink:0}} />;

const Toggle = ({on,toggle}) => <div onClick={toggle} style={{width:38,height:21,borderRadius:11,flexShrink:0,cursor:"pointer",background:on?"var(-ac)":"var(-cH)",border:`1px solid ${on?"var(--ac)":"var(--bH)"}`,position:"relative",transition:"background .22s",boxShadow:on?"0 0 12px rgba(var(-ar),.35)":"none"}}><div style={{position:"absolute",top:2,left:on?19:2,width:15,height:15,borderRadius:"50%",background:"#fff",boxShadow:"0 1px 4px rgba(0,0,0,.25)",transition:"left .22s cubic-bezier(.22,1,.36,1)"}} /></div>;

const LiveDot = () => <span style={{display:"inline-flex",alignItems:"center",gap:5,fontSize:10,color:"var(-ok)",fontWeight:800,letterSpacing:".8px"}}><span style={{width:6,height:6,borderRadius:"50%",background:"var(-ok)",boxShadow:"0 0 6px var(-ok)",animation:"pulse 2s infinite"}} />LIVE</span>;

const Dv = () => <div style={{height:1,background:"var(-b)",margin:"2px 0"}} />;

const SHd = ({title,sub,end}) => (

  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:10,marginBottom:20}}>
    <div><h2 style={{fontSize:20,fontWeight:800,color:"var(--t1)",letterSpacing:"-.4px",lineHeight:1.2}}>{title}</h2>{sub&&<p style={{fontSize:12,color:"var(--t2)",marginTop:3}}>{sub}</p>}</div>
    {end&&<div style={{display:"flex",gap:7,flexWrap:"wrap"}}>{end}</div>}
  </div>
);

// ─────────────────────────────────────────────────────────────────────────────
// CHARTS
// ─────────────────────────────────────────────────────────────────────────────
const Spark = ({vals,color,w=80,h=28}) => {
const mn=Math.min(...vals),mx=Math.max(...vals),rng=mx-mn||1;
const pts=vals.map((v,i)=>((i/(vals.length-1))*w)+","+((h)-((v-mn)/rng)*(h*.8))).join(" ");
const fill=pts+" "+w+","+h+" 0,"+h;
const id="sg"+Math.random().toString(36).slice(2,8);
return <svg width={w} height={h} style={{display:"block",overflow:"visible"}}><defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={color} stopOpacity=".35"/><stop offset="100%" stopColor={color} stopOpacity="0"/></linearGradient></defs><polygon points={fill} fill={"url(#"+id+")"}/><polyline points={pts} fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"/></svg>;
};

const BarChart = ({data}) => {
const mx = Math.max(...data.map(d=>Math.max(d.i,d.e)));
return <div style={{display:"flex",alignItems:"flex-end",gap:5,height:96,position:"relative",paddingBottom:18}}>{data.map((d,i)=><div key={i} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:2}}><div style={{display:"flex",alignItems:"flex-end",gap:2,height:72}}><div style={{width:9,borderRadius:"3px 3px 0 0",minHeight:3,background:"var(-ac)",opacity:i===data.length-1?1:.5,height:((d.i/mx)*100)+"%",animation:"barUp .7s ease both",animationDelay:(i*.07)+"s"}}/><div style={{width:9,borderRadius:"3px 3px 0 0",minHeight:3,background:"var(-er)",opacity:.55,height:((d.e/mx)*100)+"%",animation:"barUp .7s ease both",animationDelay:(i*.07+.05)+"s"}}/></div><span className="mono" style={{fontSize:8,color:"var(-t3)",position:"absolute",bottom:2}}>{d.m}</span></div>)}</div>;
};

const Donut = ({pct,color,size=52,thick=5}) => {
const r=(size-thick*2)/2, c=2*Math.PI*r, d=c*(pct/100);
return <svg width={size} height={size} style={{transform:"rotate(-90deg)"}}><circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--b)" strokeWidth={thick}/><circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={thick} strokeDasharray={d+" "+c} strokeLinecap="round" style={{transition:"stroke-dasharray .9s cubic-bezier(.22,1,.36,1)"}}/></svg>;
};

const Counter = ({to,prefix=""}) => {
const [v,setV]=useState(0); const r=useRef();
useEffect(()=>{ const n=Number(to)||0,dur=1100,s=Date.now(); const tick=()=>{ const p=Math.min((Date.now()-s)/dur,1),e=1-Math.pow(1-p,4); setV(Math.round(n*e)); if(p<1) r.current=requestAnimationFrame(tick); }; r.current=requestAnimationFrame(tick); return()=>cancelAnimationFrame(r.current); },[to]);
return <span>{prefix}{v.toLocaleString()}</span>;
};

// ─────────────────────────────────────────────────────────────────────────────
// DEMO DATA
// ─────────────────────────────────────────────────────────────────────────────
const D = {
kpis:[
{k:"revenue",      v:4820000,ch:+18.4,sp:[2.1,2.4,2.8,2.5,3.2,3.8,4.2,4.82],icon:"↑"},
{k:"expenses",     v:1230000,ch:-5.2, sp:[1.1,1.3,1.2,1.0,1.1,1.3,1.1,1.23],icon:"↓"},
{k:"netProfit",    v:3590000,ch:+23.1,sp:[1.0,1.1,1.5,1.5,2.0,2.5,3.1,3.59],icon:"◈"},
{k:"activeClients",v:47,     ch:+3,   sp:[38,40,40,41,42,44,45,47],          icon:"◉"},
],
flow:[{m:"Nov",i:2100,e:890},{m:"Dec",i:2800,e:1100},{m:"Jan",i:3200,e:980},{m:"Feb",i:2900,e:1050},{m:"Mar",i:3800,e:1200},{m:"Apr",i:4200,e:1180},{m:"May",i:4820,e:1230}],
txns:[
{id:"TXN-001",date:"2026-05-03",desc:"Client Payment - OHADA Accounting Pro",cat:"Revenue",   amt:850000,t:"income"},
{id:"TXN-002",date:"2026-05-02",desc:"AWS Lightsail Hosting",                  cat:"Ops",     amt:45000, t:"expense"},
{id:"TXN-003",date:"2026-05-02",desc:"Gumroad Tool Sales",                     cat:"Revenue", amt:320000,t:"income"},
{id:"TXN-004",date:"2026-05-01",desc:"Office Supplies",                        cat:"Admin",   amt:12000, t:"expense"},
{id:"TXN-005",date:"2026-04-30",desc:"Etsy Excel Manager Sales",               cat:"Revenue", amt:180000,t:"income"},
{id:"TXN-006",date:"2026-04-29",desc:"Pharmacy Manager License",               cat:"Revenue", amt:150000,t:"income"},
{id:"TXN-007",date:"2026-04-28",desc:"MTN Internet Bundle",                    cat:"Ops",     amt:25000, t:"expense"},
{id:"TXN-008",date:"2026-04-27",desc:"Restaurant Manager - New Client",        cat:"Revenue", amt:120000,t:"income"},
],
clients:[
{id:"C001",n:"Pharmacie Centrale",   p:"Pharmacy Manager",mrr:15000,s:"active",r:"2026-08-01",city:"Douala"},
{id:"C002",n:"Restaurant Le Bon Gout",p:"Snack Bar Mgr",  mrr:12000,s:"active",r:"2026-07-15",city:"Limbe"},
{id:"C003",n:"Brocante Limbe",       p:"Brocante Manager",mrr:10000,s:"active",r:"2026-06-30",city:"Limbe"},
{id:"C004",n:"Tech Startup Douala",  p:"OHADA Pro",       mrr:45000,s:"active",r:"2027-01-10",city:"Douala"},
{id:"C005",n:"Mini Supermarche",     p:"Retail Manager",  mrr:15000,s:"trial", r:"2026-05-20",city:"Buea"},
{id:"C006",n:"Clinique Moderne",     p:"Healthcare Mgr",  mrr:20000,s:"active",r:"2026-09-01",city:"Yaounde"},
],
products:[{id:"P001",n:"OHADA Accounting Pro",sku:"SFT-001",price:120000,s:"active"},{id:"P002",n:"Pharmacy Manager v2",sku:"SFT-002",price:75000,s:"active"},{id:"P003",n:"Restaurant Manager",sku:"SFT-003",price:65000,s:"active"},{id:"P004",n:"Brocante Manager",sku:"SFT-004",price:55000,s:"active"},{id:"P005",n:"Snack Bar Manager",sku:"SFT-005",price:55000,s:"active"},{id:"P006",n:"BizTracker 2.0",sku:"SFT-006",price:45000,s:"draft"}],
invoices:[{id:"INV-2026-001",client:"Tech Startup Douala",amt:120000,due:"2026-05-15",s:"pending"},{id:"INV-2026-002",client:"Pharmacie Centrale",amt:75000,due:"2026-05-10",s:"paid"},{id:"INV-2026-003",client:"Restaurant Le Bon Gout",amt:65000,due:"2026-05-20",s:"pending"},{id:"INV-2026-004",client:"Clinique Moderne",amt:90000,due:"2026-04-30",s:"overdue"},{id:"INV-2026-005",client:"Mini Supermarche",amt:55000,due:"2026-05-25",s:"draft"}],
employees:[{id:"E001",n:"Likafi Jr",role:"Director",salary:200000},{id:"E002",n:"Marie Nkweti",role:"Developer",salary:150000},{id:"E003",n:"Jean Mballa",role:"Sales Rep",salary:100000},{id:"E004",n:"Carine Etoga",role:"Accountant",salary:120000}],
aiSeed:[{r:"assistant",t:"✦ Hello! I'm your AI Business Assistant - fully loaded with your company data.\n\n📊 Revenue MTD: 4,820,000 FCFA (↑18.4%)\n💰 Net Profit: 3,590,000 FCFA - 74% margin\n👥 6 clients · MRR: 87,000 FCFA\n⚠️ Mini Supermarche trial ends in 17 days!\n\nAsk me anything or use the quick commands."}],
};

// ═════════════════════════════════════════════════════════════════════════════
// LANDING PAGE - Public-facing, converts visitors to sign-ups
// ═════════════════════════════════════════════════════════════════════════════
const Landing = ({onStart, onSignin}) => {
const {tr,lang,setLang} = useApp();
const [activePlan,setActivePlan] = useState("pro");
const [cur,setCur] = useState("XAF");
const heroRef = useRef();

const LANGS = [["en","EN"],["fr","FR"],["es","ES"],["pt","PT"],["sw","SW"],["de","DE"]];

const statsMarquee = [
"47 Active Clients","FCFA 4.8M Revenue MTD","74% Profit Margin","6 Languages","7 Themes","OHADA Compliant","Real-time AI","14-day Free Trial",
"47 Active Clients","FCFA 4.8M Revenue MTD","74% Profit Margin","6 Languages","7 Themes","OHADA Compliant","Real-time AI","14-day Free Trial",
];

return (
<div style={{height:"100vh",overflowY:"auto",background:"var(-bg)"}}>
{/* ── NAV ────────────────────────────────────────────── */}
<nav style={{position:"sticky",top:0,zIndex:100,background:"rgba(var(-ar),.0)",backdropFilter:"blur(20px)",WebkitBackdropFilter:"blur(20px)",borderBottom:"1px solid var(-b)",padding:"0 24px",height:58,display:"flex",alignItems:"center",gap:16}}>
<div style={{display:"flex",alignItems:"center",gap:8,flex:1}}>
<div style={{width:30,height:30,borderRadius:8,background:"linear-gradient(135deg,var(-ac),var(-ac2))",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,animation:"glowP 4s ease infinite"}}>⬡</div>
<span style={{fontSize:15,fontWeight:800,color:"var(-t1)",letterSpacing:"-.3px"}}>Lekoev<span style={{color:"var(-ac)"}}>.</span>BOS</span>
</div>

    <div className="mh" style={{display:"flex",gap:24,alignItems:"center"}}>
      {[["#features",tr.features],["#pricing",tr.pricing],["#about",tr.about]].map(([h,l])=>(
        <a key={h} href={h} style={{fontSize:13,fontWeight:600,color:"var(--t2)",textDecoration:"none",transition:"color .15s"}} onMouseEnter={e=>e.target.style.color="var(--t1)"} onMouseLeave={e=>e.target.style.color="var(--t2)"}>{l}</a>
      ))}
    </div>

    <div style={{display:"flex",alignItems:"center",gap:8}}>
      <select value={lang} onChange={e=>setLang(e.target.value)} style={{width:58,padding:"5px 8px",fontSize:11,fontWeight:700,borderRadius:7,height:30}}>
        {LANGS.map(([id,l])=><option key={id} value={id}>{l}</option>)}
      </select>
      <Btn v="gh" sz="sm" onClick={onSignin}>{tr.signin}</Btn>
      <Btn sz="sm" onClick={onStart}>{tr.start}</Btn>
    </div>
  </nav>

  {/* ── HERO ───────────────────────────────────────────── */}
  <section ref={heroRef} style={{minHeight:"90vh",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",textAlign:"center",padding:"60px 24px 40px",position:"relative",overflow:"hidden"}}>
    {/* bg effects */}
    <div style={{position:"absolute",top:"10%",left:"15%",width:500,height:500,borderRadius:"50%",background:"radial-gradient(circle,rgba(var(--ar),.1) 0%,transparent 70%)",animation:"floatY 8s ease-in-out infinite",pointerEvents:"none"}}/>
    <div style={{position:"absolute",bottom:"10%",right:"10%",width:400,height:400,borderRadius:"50%",background:"radial-gradient(circle,rgba(var(--ar),.07) 0%,transparent 70%)",animation:"floatY 10s ease-in-out infinite",animationDelay:"-4s",pointerEvents:"none"}}/>
    <div style={{position:"absolute",inset:0,backgroundImage:"linear-gradient(var(--b) 1px,transparent 1px),linear-gradient(90deg,var(--b) 1px,transparent 1px)",backgroundSize:"56px 56px",opacity:.6,pointerEvents:"none"}}/>

    {/* Badge */}
    <div className="aFU" style={{display:"inline-flex",alignItems:"center",gap:7,padding:"6px 14px",borderRadius:99,background:"rgba(var(--ar),.1)",border:"1px solid rgba(var(--ar),.25)",fontSize:11.5,fontWeight:700,color:"var(--ac)",marginBottom:28,letterSpacing:".5px"}}>
      <span style={{width:6,height:6,borderRadius:"50%",background:"var(--ok)",animation:"pulse 2s infinite"}}/>
      v4.0 - {tr.trialDays} · {tr.noCard}
    </div>

    <h1 className="aFU d1" style={{fontSize:"clamp(32px,6vw,72px)",fontWeight:800,lineHeight:1.1,letterSpacing:"-2px",maxWidth:800,marginBottom:20}}>
      <span className="gtext">{tr.hero}</span>
    </h1>

    <p className="aFU d2" style={{fontSize:"clamp(14px,2vw,18px)",color:"var(--t2)",maxWidth:560,marginBottom:36,lineHeight:1.6}}>{tr.sub}</p>

    <div className="aFU d3" style={{display:"flex",gap:12,flexWrap:"wrap",justifyContent:"center",marginBottom:48}}>
      <Btn sz="xl" onClick={onStart} style={{gap:8}}>
        ⬡ {tr.start}
      </Btn>
      <Btn v="ol" sz="xl" onClick={onSignin}>{tr.signin}</Btn>
    </div>

    {/* Trust indicators */}
    <div className="aFU d4" style={{display:"flex",gap:24,flexWrap:"wrap",justifyContent:"center",fontSize:12,color:"var(--t3)",fontWeight:600}}>
      {["🔒 Bank-grade security","🌍 6 African currencies","⚡ AI-powered","📱 Mobile-first","🤝 OHADA compliant"].map((f,i)=><span key={i}>{f}</span>)}
    </div>

    {/* Dashboard preview mockup */}
    <div className="aFU d5" style={{marginTop:52,width:"100%",maxWidth:860,borderRadius:18,overflow:"hidden",border:"1px solid var(--bH)",boxShadow:"0 32px 80px rgba(0,0,0,.5)",position:"relative"}}>
      <div style={{background:"var(--p)",padding:"10px 16px",display:"flex",alignItems:"center",gap:8}}>
        <div style={{display:"flex",gap:6}}>{["#ff5f57","#febc2e","#28c840"].map((c,i)=><div key={i} style={{width:11,height:11,borderRadius:"50%",background:c}}/>)}</div>
        <div style={{flex:1,background:"var(--c)",borderRadius:6,height:24,display:"flex",alignItems:"center",justifyContent:"center"}}><span style={{fontSize:11,color:"var(--t3)"}}>bos.lekoev.com - Dashboard</span></div>
      </div>
      <div style={{background:"var(--bg)",padding:16,display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10}}>
        {[{l:"Revenue",v:"4.82M FCFA",c:"var(--ok)",up:"+18.4%"},{l:"Net Profit",v:"3.59M FCFA",c:"var(--ac)",up:"+23.1%"},{l:"Clients",v:"47",c:"var(--ac2)",up:"+3"},{l:"MRR",v:"87K FCFA",c:"var(--wn)",up:"+12%"}].map((k,i)=>(
          <div key={i} style={{background:"var(--c)",borderRadius:10,padding:"12px 14px",border:"1px solid var(--b)"}}>
            <p style={{fontSize:9,color:"var(--t3)",fontWeight:700,textTransform:"uppercase",letterSpacing:1,marginBottom:6}}>{k.l}</p>
            <p className="mono" style={{fontSize:13,fontWeight:700,color:k.c,marginBottom:4}}>{k.v}</p>
            <p style={{fontSize:9,color:"var(--ok)",fontWeight:700}}>{k.up}</p>
          </div>
        ))}
      </div>
    </div>
  </section>

  {/* ── MARQUEE ────────────────────────────────────────── */}
  <div style={{overflow:"hidden",borderTop:"1px solid var(--b)",borderBottom:"1px solid var(--b)",padding:"12px 0",background:"var(--p)"}}>
    <div style={{display:"flex",gap:32,animation:"marquee 30s linear infinite",whiteSpace:"nowrap",width:"max-content"}}>
      {statsMarquee.map((s,i)=>(
        <span key={i} style={{fontSize:12,fontWeight:600,color:"var(--t2)",display:"flex",alignItems:"center",gap:8}}>
          <span style={{color:"var(--ac)"}}>✦</span> {s}
        </span>
      ))}
    </div>
  </div>

  {/* ── FEATURES ───────────────────────────────────────── */}
  <section id="features" style={{padding:"80px 24px",maxWidth:1100,margin:"0 auto"}}>
    <div style={{textAlign:"center",marginBottom:52}}>
      <Badge c="ac" style={{marginBottom:16}}>✦ {tr.features}</Badge>
      <h2 style={{fontSize:"clamp(28px,4vw,48px)",fontWeight:800,letterSpacing:"-1.5px",marginBottom:12}}>Everything your business needs</h2>
      <p style={{fontSize:15,color:"var(--t2)",maxWidth:480,margin:"0 auto"}}>One platform to run accounting, manage clients, pay staff, and grow with AI.</p>
    </div>

    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(280px,1fr))",gap:16}}>
      {[
        {icon:"📊",title:"OHADA Accounting",desc:"Full double-entry ledger, journal, balance sheet, P&L - SYSCOHADA compliant out of the box."},
        {icon:"✦",title:"AI Business Assistant",desc:"Voice + text commands. Ask about revenue, add transactions, get forecasts - always online, never errors."},
        {icon:"📄",title:"Invoicing & Billing",desc:"Create, send, and track professional invoices. Auto-remind clients. Mark paid with one tap."},
        {icon:"💼",title:"Payroll Management",desc:"Calculate salaries, generate payslips, handle CNPS/IRPP deductions automatically."},
        {icon:"📦",title:"Inventory Control",desc:"Track stock in real-time. Low-stock alerts. Sales history. Multi-location support."},
        {icon:"🔑",title:"Passkey Licensing",desc:"Admin-generated passkeys per device. Control exactly who has access and for how long."},
      ].map((f,i)=>(
        <Card key={i} hov className={"aFU d"+Math.min(i+1,6)} style={{padding:"22px 24px"}}>
          <div style={{fontSize:28,marginBottom:14}}>{f.icon}</div>
          <p style={{fontSize:15,fontWeight:800,color:"var(--t1)",marginBottom:6,letterSpacing:"-.3px"}}>{f.title}</p>
          <p style={{fontSize:13,color:"var(--t2)",lineHeight:1.6}}>{f.desc}</p>
        </Card>
      ))}
    </div>
  </section>

  {/* ── PRICING ────────────────────────────────────────── */}
  <section id="pricing" style={{padding:"80px 24px",background:"var(--p)"}}>
    <div style={{maxWidth:1100,margin:"0 auto"}}>
      <div style={{textAlign:"center",marginBottom:52}}>
        <Badge c="ac" style={{marginBottom:16}}>💎 {tr.pricing}</Badge>
        <h2 style={{fontSize:"clamp(28px,4vw,48px)",fontWeight:800,letterSpacing:"-1.5px",marginBottom:12}}>{tr.choosePlan}</h2>
        <p style={{fontSize:13,color:"var(--t2)",marginBottom:20}}>{tr.noCard}</p>
        {/* Currency selector for pricing */}
        <div style={{display:"flex",gap:8,justifyContent:"center",flexWrap:"wrap"}}>
          {["XAF","USD","EUR","GBP"].map(c=>(
            <button key={c} onClick={()=>setCur(c)} style={{padding:"5px 12px",borderRadius:20,fontSize:11,fontWeight:700,border:`1.5px solid ${cur===c?"var(--ac)":"var(--bH)"}`,background:cur===c?"rgba(var(--ar),.1)":"transparent",color:cur===c?"var(--ac)":"var(--t2)",cursor:"pointer",transition:"all .18s"}}>{CURRENCIES[c].s} {c}</button>
          ))}
        </div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(240px,1fr))",gap:16,alignItems:"start"}}>
        {PLANS.map((pl,i)=>{
          const isActive = activePlan===pl.id;
          const displayPrice = cur==="XAF" ? (pl.priceXAF ? money(pl.priceXAF,"XAF") : null) : pl.price ? "$"+pl.price : null;
          return (
            <div key={pl.id} onClick={()=>setActivePlan(pl.id)} style={{padding:"24px",borderRadius:16,border:`2px solid ${isActive?"var(--ac)":pl.badge?"rgba(var(--ar),.2)":"var(--b)"}`,background:isActive?"rgba(var(--ar),.06)":"var(--c)",cursor:"pointer",transition:"all .22s",position:"relative",transform:isActive?"scale(1.02)":"scale(1)"}}>
              {pl.badge && <div style={{position:"absolute",top:-12,left:"50%",transform:"translateX(-50%)",background:pl.color,color:"#fff",fontSize:10,fontWeight:800,padding:"3px 12px",borderRadius:99,letterSpacing:".5px",whiteSpace:"nowrap"}}>{pl.badge}</div>}
              <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:16}}>
                <div style={{width:36,height:36,borderRadius:10,background:pl.color+"22",border:`1px solid ${pl.color}44`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,color:pl.color}}>
                  {["⬡","◈","◉","♚"][i]}
                </div>
                <p style={{fontSize:16,fontWeight:800,color:"var(--t1)"}}>{pl.label}</p>
              </div>

              <div style={{marginBottom:16}}>
                {pl.period==="forever" ? (
                  <p style={{fontSize:28,fontWeight:800,color:pl.color}}>{tr.free}</p>
                ) : pl.period==="custom" ? (
                  <p style={{fontSize:22,fontWeight:800,color:pl.color}}>{tr.custom}</p>
                ) : (
                  <div style={{display:"flex",alignItems:"flex-end",gap:4}}>
                    <p style={{fontSize:28,fontWeight:800,color:pl.color}}>{displayPrice}</p>
                    <p style={{fontSize:13,color:"var(--t2)",marginBottom:4}}>{tr.mo}</p>
                  </div>
                )}
              </div>

              <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:20}}>
                {PLAN_FEATURES[pl.id].map((f,fi)=>(
                  <div key={fi} style={{display:"flex",gap:8,alignItems:"flex-start"}}>
                    <span style={{color:pl.color,fontSize:12,fontWeight:800,flexShrink:0,marginTop:1}}>✓</span>
                    <span style={{fontSize:12,color:"var(--t2)"}}>{f}</span>
                  </div>
                ))}
              </div>

              <Btn v={pl.period==="custom"?"gh":"pri"} full sz="md" onClick={e=>{e.stopPropagation(); onStart(pl.id);}}>
                {pl.period==="custom"?tr.contactUs:pl.period==="forever"?tr.start:tr.getStarted}
              </Btn>
            </div>
          );
        })}
      </div>

      {/* All plans include */}
      <div style={{marginTop:44,textAlign:"center"}}>
        <p style={{fontSize:12,color:"var(--t3)",fontWeight:600,marginBottom:14,textTransform:"uppercase",letterSpacing:1}}>{tr.allPlans}</p>
        <div style={{display:"flex",gap:10,flexWrap:"wrap",justifyContent:"center"}}>
          {ALL_FEATURES.map((f,i)=><Badge key={i} c="def">{f}</Badge>)}
        </div>
      </div>
    </div>
  </section>

  {/* ── ABOUT / CTA ────────────────────────────────────── */}
  <section id="about" style={{padding:"80px 24px",textAlign:"center"}}>
    <div style={{maxWidth:600,margin:"0 auto"}}>
      <div style={{fontSize:48,marginBottom:20,animation:"floatY 3s ease-in-out infinite"}}>⬡</div>
      <h2 style={{fontSize:"clamp(28px,4vw,44px)",fontWeight:800,letterSpacing:"-1.5px",marginBottom:14}}>Built by <span className="gtext">Likafi Jr</span></h2>
      <p style={{fontSize:14,color:"var(--t2)",lineHeight:1.7,marginBottom:28}}>Lekoev BOS was built from the ground up for African SMEs - understanding OHADA accounting, XAF currency, and the real challenges of running a business in Cameroon and across the continent. This isn't a Western app adapted for Africa. This is Africa-first.</p>
      <div style={{display:"flex",gap:12,justifyContent:"center",flexWrap:"wrap"}}>
        <Btn sz="lg" onClick={onStart}>{tr.start} - {tr.trialDays}</Btn>
        <Btn v="gh" sz="lg" onClick={onSignin}>{tr.signin}</Btn>
      </div>
    </div>
  </section>

  {/* ── FOOTER ─────────────────────────────────────────── */}
  <footer style={{borderTop:"1px solid var(--b)",padding:"24px",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:12}}>
    <div style={{display:"flex",alignItems:"center",gap:8}}>
      <div style={{width:24,height:24,borderRadius:6,background:"linear-gradient(135deg,var(--ac),var(--ac2))",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12}}>⬡</div>
      <span style={{fontSize:12,color:"var(--t2)",fontWeight:600}}>Lekoev.BOS</span>
    </div>
    <p style={{fontSize:11,color:"var(--t3)"}}>{tr.copy}</p>
    <p style={{fontSize:11,color:"var(--t3)"}}>{tr.by}</p>
  </footer>
</div>

);
};

// ═════════════════════════════════════════════════════════════════════════════
// SIGN IN - Returning users
// ═════════════════════════════════════════════════════════════════════════════
const SignIn = ({onLogin, onBack}) => {
const {tr, soundOn} = useApp();
const [email,setEmail] = useState("");
const [pass,setPass] = useState("");
const [pk,setPk] = useState("");
const [step,setStep] = useState(0);
const [err,setErr] = useState("");
const [busy,setBusy] = useState(false);

const go = async fn => { setErr(""); setBusy(true); await new Promise(r=>setTimeout(r,800)); setBusy(false); fn(); };
const s0 = () => { if(!email) return setErr("Email required"); if(soundOn) SFX.tap(); go(()=>setStep(1)); };
const s1 = () => { if(!pass) return setErr("Password required"); if(soundOn) SFX.tap(); go(()=>setStep(2)); };
const s2 = () => {
if(!pk) return setErr("Passkey required");
if(pk.length<4) return setErr("Invalid - try: LKV-DEMO");
if(soundOn) SFX.success();
go(()=>onLogin({email,name:email.split("@")[0],plan:"pro",biz:"Lekoev Enterprises",cur:"XAF",isNew:false}));
};

return (
<div style={{minHeight:"100vh",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",background:"var(-bg)",position:"relative",overflow:"hidden",padding:"0 18px"}}>
<div style={{position:"absolute",inset:0,backgroundImage:"linear-gradient(var(-b) 1px,transparent 1px),linear-gradient(90deg,var(-b) 1px,transparent 1px)",backgroundSize:"52px 52px",opacity:.6,pointerEvents:"none"}}/>
<div style={{position:"absolute",top:"-10%",left:"-5%",width:500,height:500,borderRadius:"50%",background:"radial-gradient(circle,rgba(var(-ar),.08) 0%,transparent 70%)",animation:"floatY 8s ease-in-out infinite",pointerEvents:"none"}}/>

  <div className="aSI" style={{width:"100%",maxWidth:400,position:"relative",zIndex:1}}>
    <button onClick={onBack} style={{background:"none",border:"none",color:"var(--t2)",cursor:"pointer",fontSize:13,fontWeight:600,marginBottom:24,display:"flex",alignItems:"center",gap:6}} onMouseEnter={e=>e.target.style.color="var(--t1)"} onMouseLeave={e=>e.target.style.color="var(--t2)"}>← Back</button>

    <div style={{textAlign:"center",marginBottom:28}}>
      <div style={{display:"inline-flex",width:52,height:52,borderRadius:14,background:"linear-gradient(145deg,var(--ac),var(--ac2))",alignItems:"center",justifyContent:"center",fontSize:22,marginBottom:14,animation:"glowP 3s ease infinite"}}>⬡</div>
      <h1 style={{fontSize:26,fontWeight:800,color:"var(--t1)",letterSpacing:"-1px"}}>Lekoev<span style={{color:"var(--ac)"}}>.</span>BOS</h1>
      <p style={{fontSize:12,color:"var(--t3)",marginTop:4,textTransform:"uppercase",letterSpacing:"2px",fontWeight:700}}>Business Operating System</p>
    </div>

    <div style={{background:"var(--p)",border:"1px solid var(--bH)",borderRadius:18,padding:"26px 24px",boxShadow:"0 28px 80px rgba(0,0,0,.4)"}}>
      <div style={{display:"flex",gap:5,marginBottom:22}}>
        {["Email","Password","Passkey"].map((_,i)=>(
          <div key={i} style={{flex:1,height:2.5,borderRadius:2,background:"var(--b)",overflow:"hidden"}}>
            <div style={{height:"100%",borderRadius:2,background:"var(--ac)",transition:"width .4s cubic-bezier(.22,1,.36,1)",width:i<step?"100%":i===step?"40%":"0%"}}/>
          </div>
        ))}
      </div>

      {step===0&&<div className="aFU">
        <p style={{fontSize:17,fontWeight:800,color:"var(--t1)",marginBottom:3}}>Welcome back</p>
        <p style={{fontSize:12.5,color:"var(--t2)",marginBottom:18}}>Sign in to your workspace</p>
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <input value={email} onChange={e=>{setEmail(e.target.value);setErr("");}} type="email" placeholder="your@business.com" autoFocus onKeyDown={e=>e.key==="Enter"&&s0()}/>
          {err&&<p className="aFI" style={{fontSize:12,color:"var(--er)",fontWeight:600}}>{err}</p>}
          <Btn onClick={s0} disabled={busy} full sz="lg">{busy?<><Spinner/>Checking...</>:"Continue →"}</Btn>
        </div>
      </div>}

      {step===1&&<div className="aFU">
        <p style={{fontSize:17,fontWeight:800,color:"var(--t1)",marginBottom:3}}>Password</p>
        <p style={{fontSize:12.5,color:"var(--t2)",marginBottom:18}}>For <strong style={{color:"var(--ac)"}}>{email}</strong></p>
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <input value={pass} onChange={e=>{setPass(e.target.value);setErr("");}} type="password" placeholder="••••••••••" autoFocus onKeyDown={e=>e.key==="Enter"&&s1()}/>
          {err&&<p className="aFI" style={{fontSize:12,color:"var(--er)",fontWeight:600}}>{err}</p>}
          <Btn onClick={s1} disabled={busy} full sz="lg">{busy?<><Spinner/>Verifying...</>:"Next →"}</Btn>
          <Btn v="gh" onClick={()=>setStep(0)} sz="sm" full>← Back</Btn>
        </div>
      </div>}

      {step===2&&<div className="aFU">
        <p style={{fontSize:17,fontWeight:800,color:"var(--t1)",marginBottom:3}}>License Passkey</p>
        <p style={{fontSize:12.5,color:"var(--t2)",marginBottom:6}}>Enter your device passkey to continue.</p>
        <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:16,padding:"8px 12px",borderRadius:8,background:"rgba(var(--ar),.08)",border:"1px solid rgba(var(--ar),.2)"}}>
          <span style={{color:"var(--ac)"}}>💡</span>
          <span style={{fontSize:11.5,color:"var(--t2)"}}>{tr.demoKey}: <strong className="mono" style={{color:"var(--ac)",letterSpacing:"1.5px"}}>LKV-DEMO</strong></span>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <input value={pk} onChange={e=>{setPk(e.target.value.toUpperCase());setErr("");}} placeholder="LKV-XXXX-XXXX" className="mono" style={{letterSpacing:"2px"}} autoFocus onKeyDown={e=>e.key==="Enter"&&s2()}/>
          {err&&<p className="aFI" style={{fontSize:12,color:"var(--er)",fontWeight:600}}>{err}</p>}
          <Btn onClick={s2} disabled={busy} full sz="lg">{busy?<><Spinner/>Activating...</>:"Activate Device →"}</Btn>
          <Btn v="gh" onClick={()=>setStep(1)} sz="sm" full>← Back</Btn>
        </div>
      </div>}
    </div>

    <p style={{textAlign:"center",fontSize:11,color:"var(--t3)",marginTop:16,fontWeight:600}}>
      Don't have an account? <button onClick={onBack} style={{background:"none",border:"none",color:"var(--ac)",cursor:"pointer",fontWeight:700,fontSize:11}}>Start free trial</button>
    </p>
  </div>
</div>

);
};

// ═════════════════════════════════════════════════════════════════════════════
// ONBOARDING WIZARD - Full business creation + plan selection
// ═════════════════════════════════════════════════════════════════════════════
const Onboarding = ({initialPlan="pro", onComplete}) => {
const {tr, soundOn} = useApp();
const [step,setStep] = useState(0);
const [form,setForm] = useState({
// Account
name:"", email:"", pass:"",
// Business
bizName:"", bizType:"", bizEmail:"", bizPhone:"", bizDesc:"",
// Location
country:"Cameroon", city:"", currency:"XAF", timezone:"Africa/Douala",
// Modules
modules:["accounting","invoicing","crm"],
// Plan
plan:initialPlan,
// Done
ready:false,
});
const [err,setErr] = useState("");
const [busy,setBusy] = useState(false);

const TOTAL = 6;
const set = (k,v) => setForm(f=>({...f,[k]:v}));
const setMods = m => { if(soundOn)SFX.tap(); set("modules",form.modules.includes(m)?form.modules.filter(x=>x!==m):[...form.modules,m]); };

const STEPS = ["Account","Business Type","Business Info","Location","Modules","Choose Plan"];

const next = async () => {
// Validation per step
if(step===0 && (!form.name||!form.email||!form.pass)) return setErr("All fields required");
if(step===1 && !form.bizType) return setErr("Select a business type");
if(step===2 && !form.bizName) return setErr("Business name required");
setErr("");
if(soundOn) SFX.whoosh();
if(step === TOTAL-1) {
setBusy(true);
await new Promise(r=>setTimeout(r,1400));
setBusy(false);
if(soundOn) SFX.upgrade();
onComplete(form);
} else {
setStep(s=>s+1);
}
};
const back = () => { if(step>0){setStep(s=>s-1); if(soundOn)SFX.tap();} };

const selectedPlanObj = PLANS.find(p=>p.id===form.plan)||PLANS[1];

return (
<div style={{minHeight:"100vh",background:"var(-bg)",display:"flex",flexDirection:"column",position:"relative",overflow:"hidden"}}>
<div style={{position:"absolute",inset:0,backgroundImage:"linear-gradient(var(-b) 1px,transparent 1px),linear-gradient(90deg,var(-b) 1px,transparent 1px)",backgroundSize:"52px 52px",opacity:.5,pointerEvents:"none"}}/>

  {/* Header */}
  <div style={{padding:"18px 24px",display:"flex",alignItems:"center",gap:12,borderBottom:"1px solid var(--b)",background:"var(--p)",position:"sticky",top:0,zIndex:10,flexShrink:0}}>
    <div style={{width:30,height:30,borderRadius:8,background:"linear-gradient(135deg,var(--ac),var(--ac2))",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14}}>⬡</div>
    <span style={{fontSize:14,fontWeight:800,color:"var(--t1)"}}>Lekoev.BOS</span>
    <div style={{flex:1}}/>
    <div style={{display:"flex",gap:5,alignItems:"center"}}>
      {STEPS.map((_,i)=>(
        <div key={i} style={{display:"flex",alignItems:"center",gap:5}}>
          <div style={{width:i<step?24:22,height:i<step?24:22,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,background:i<step?"var(--ok)":i===step?"var(--ac)":"var(--b)",color:i<=step?"var(--bg)":"var(--t3)",transition:"all .3s"}}>
            {i<step?"✓":i+1}
          </div>
          {i<STEPS.length-1&&<div style={{width:24,height:2,borderRadius:1,background:i<step?"var(--ok)":"var(--b)",transition:"background .3s"}} className="mh"/>}
        </div>
      ))}
    </div>
  </div>

  {/* Body */}
  <div style={{flex:1,overflowY:"auto",padding:"32px 24px",display:"flex",flexDirection:"column",alignItems:"center"}}>
    <div style={{width:"100%",maxWidth:580}}>
      {/* Step label */}
      <div style={{marginBottom:6}}>
        <p style={{fontSize:11,color:"var(--t3)",fontWeight:700,textTransform:"uppercase",letterSpacing:"1.5px"}}>Step {step+1} of {TOTAL}</p>
      </div>

      {/* STEP 0 - Account */}
      {step===0&&<div className="aFU">
        <h2 style={{fontSize:26,fontWeight:800,color:"var(--t1)",letterSpacing:"-.5px",marginBottom:4}}>Create your account</h2>
        <p style={{fontSize:13,color:"var(--t2)",marginBottom:24}}>You'll use this to log in to Lekoev BOS</p>
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          <div>
            <label style={{fontSize:11,color:"var(--t2)",display:"block",marginBottom:5,fontWeight:700}}>Full Name</label>
            <input value={form.name} onChange={e=>set("name",e.target.value)} placeholder="Likafi Jr" autoFocus/>
          </div>
          <div>
            <label style={{fontSize:11,color:"var(--t2)",display:"block",marginBottom:5,fontWeight:700}}>Email Address</label>
            <input value={form.email} onChange={e=>set("email",e.target.value)} type="email" placeholder="you@company.com"/>
          </div>
          <div>
            <label style={{fontSize:11,color:"var(--t2)",display:"block",marginBottom:5,fontWeight:700}}>Password</label>
            <input value={form.pass} onChange={e=>set("pass",e.target.value)} type="password" placeholder="Min. 8 characters"/>
          </div>
          {err&&<p className="aFI" style={{fontSize:12,color:"var(--er)",fontWeight:600}}>{err}</p>}
        </div>
      </div>}

      {/* STEP 1 - Business Type */}
      {step===1&&<div className="aFU">
        <h2 style={{fontSize:26,fontWeight:800,color:"var(--t1)",letterSpacing:"-.5px",marginBottom:4}}>{tr.selectBiz}</h2>
        <p style={{fontSize:13,color:"var(--t2)",marginBottom:24}}>We'll customize your modules for your industry</p>
        {err&&<p className="aFI" style={{fontSize:12,color:"var(--er)",fontWeight:600,marginBottom:12}}>{err}</p>}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          {BIZ_TYPES.map(bt=>(
            <div key={bt.id} onClick={()=>{set("bizType",bt.id);if(soundOn)SFX.tap();}} style={{display:"flex",alignItems:"center",gap:10,padding:"12px 14px",borderRadius:11,border:`1.5px solid ${form.bizType===bt.id?"var(--ac)":"var(--bH)"}`,background:form.bizType===bt.id?"rgba(var(--ar),.1)":"var(--c)",cursor:"pointer",transition:"all .18s"}}>
              <span style={{fontSize:20}}>{bt.icon}</span>
              <span style={{fontSize:12.5,fontWeight:600,color:form.bizType===bt.id?"var(--ac)":"var(--t1)"}}>{bt.label}</span>
            </div>
          ))}
        </div>
      </div>}

      {/* STEP 2 - Business Info */}
      {step===2&&<div className="aFU">
        <h2 style={{fontSize:26,fontWeight:800,color:"var(--t1)",letterSpacing:"-.5px",marginBottom:4}}>{tr.bizDetails}</h2>
        <p style={{fontSize:13,color:"var(--t2)",marginBottom:24}}>Tell us about your business</p>
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          <div>
            <label style={{fontSize:11,color:"var(--t2)",display:"block",marginBottom:5,fontWeight:700}}>{tr.businessName} *</label>
            <input value={form.bizName} onChange={e=>set("bizName",e.target.value)} placeholder="e.g. Pharmacie Centrale" autoFocus/>
          </div>
          <div>
            <label style={{fontSize:11,color:"var(--t2)",display:"block",marginBottom:5,fontWeight:700}}>Business Email</label>
            <input value={form.bizEmail} onChange={e=>set("bizEmail",e.target.value)} type="email" placeholder="contact@company.com"/>
          </div>
          <div>
            <label style={{fontSize:11,color:"var(--t2)",display:"block",marginBottom:5,fontWeight:700}}>Phone Number</label>
            <input value={form.bizPhone} onChange={e=>set("bizPhone",e.target.value)} placeholder="+237 6XX XXX XXX"/>
          </div>
          <div>
            <label style={{fontSize:11,color:"var(--t2)",display:"block",marginBottom:5,fontWeight:700}}>What does your business do?</label>
            <textarea value={form.bizDesc} onChange={e=>set("bizDesc",e.target.value)} placeholder="Brief description..." style={{height:80,resize:"none"}}/>
          </div>
          {err&&<p className="aFI" style={{fontSize:12,color:"var(--er)",fontWeight:600}}>{err}</p>}
        </div>
      </div>}

      {/* STEP 3 - Location */}
      {step===3&&<div className="aFU">
        <h2 style={{fontSize:26,fontWeight:800,color:"var(--t1)",letterSpacing:"-.5px",marginBottom:4}}>{tr.location}</h2>
        <p style={{fontSize:13,color:"var(--t2)",marginBottom:24}}>Set your operating region and currency</p>
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          <div>
            <label style={{fontSize:11,color:"var(--t2)",display:"block",marginBottom:5,fontWeight:700}}>Country</label>
            <select value={form.country} onChange={e=>set("country",e.target.value)}>
              {["Cameroon","Nigeria","Ghana","Kenya","South Africa","Cote d Ivoire","Senegal","Rwanda","Ethiopia","Tanzania","Uganda","Egypt","Morocco","Other"].map(c=><option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label style={{fontSize:11,color:"var(--t2)",display:"block",marginBottom:5,fontWeight:700}}>City</label>
            <input value={form.city} onChange={e=>set("city",e.target.value)} placeholder="e.g. Douala, Limbe, Nairobi"/>
          </div>
          <div>
            <label style={{fontSize:11,color:"var(--t2)",display:"block",marginBottom:5,fontWeight:700}}>Currency</label>
            <select value={form.currency} onChange={e=>set("currency",e.target.value)}>
              {Object.entries(CURRENCIES).map(([code,c])=><option key={code} value={code}>{c.s} - {code}</option>)}
            </select>
          </div>
          <div>
            <label style={{fontSize:11,color:"var(--t2)",display:"block",marginBottom:5,fontWeight:700}}>Timezone</label>
            <select value={form.timezone} onChange={e=>set("timezone",e.target.value)}>
              {["Africa/Douala","Africa/Lagos","Africa/Nairobi","Africa/Johannesburg","Africa/Cairo","Europe/Paris","UTC"].map(t=><option key={t}>{t}</option>)}
            </select>
          </div>
        </div>
      </div>}

      {/* STEP 4 - Modules */}
      {step===4&&<div className="aFU">
        <h2 style={{fontSize:26,fontWeight:800,color:"var(--t1)",letterSpacing:"-.5px",marginBottom:4}}>{tr.modules}</h2>
        <p style={{fontSize:13,color:"var(--t2)",marginBottom:24}}>Choose the features for your business - you can change these any time</p>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          {MODULES_LIST.map(m=>{
            const on = form.modules.includes(m.id);
            return <div key={m.id} onClick={()=>setMods(m.id)} style={{display:"flex",alignItems:"center",gap:10,padding:"12px 14px",borderRadius:11,border:`1.5px solid ${on?"var(--ac)":"var(--bH)"}`,background:on?"rgba(var(--ar),.1)":"var(--c)",cursor:"pointer",transition:"all .18s"}}>
              <span style={{fontSize:20}}>{m.icon}</span>
              <div style={{flex:1,minWidth:0}}>
                <p style={{fontSize:12.5,fontWeight:700,color:on?"var(--ac)":"var(--t1)"}}>{m.label}</p>
                <p style={{fontSize:10.5,color:"var(--t2)"}}>{m.desc}</p>
              </div>
              {on&&<span style={{color:"var(--ac)",fontSize:14,fontWeight:900,flexShrink:0}}>✓</span>}
            </div>;
          })}
        </div>
      </div>}

      {/* STEP 5 - Plan */}
      {step===5&&<div className="aFU">
        <h2 style={{fontSize:26,fontWeight:800,color:"var(--t1)",letterSpacing:"-.5px",marginBottom:4}}>{tr.selectPlan}</h2>
        <p style={{fontSize:13,color:"var(--t2)",marginBottom:24}}>{tr.trialDays} on any paid plan · {tr.noCard}</p>
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {PLANS.map(pl=>(
            <div key={pl.id} onClick={()=>{set("plan",pl.id);if(soundOn)SFX.tap();}} style={{padding:"16px 18px",borderRadius:12,cursor:"pointer",border:`2px solid ${form.plan===pl.id?"var(--ac)":"var(--bH)"}`,background:form.plan===pl.id?"rgba(var(--ar),.07)":"var(--c)",transition:"all .18s",position:"relative"}}>
              {pl.badge&&<div style={{position:"absolute",top:-10,right:16,background:pl.color,color:"#fff",fontSize:9,fontWeight:800,padding:"2px 10px",borderRadius:99,letterSpacing:".5px"}}>{pl.badge}</div>}
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                <div style={{display:"flex",alignItems:"center",gap:10}}>
                  <div style={{width:30,height:30,borderRadius:8,background:pl.color+"22",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,color:pl.color}}>
                    {["⬡","◈","◉","♚"][PLANS.indexOf(pl)]}
                  </div>
                  <p style={{fontSize:14,fontWeight:800,color:form.plan===pl.id?"var(--ac)":"var(--t1)"}}>{pl.label}</p>
                </div>
                <div style={{textAlign:"right"}}>
                  {pl.period==="forever"?<p style={{fontSize:16,fontWeight:800,color:pl.color}}>Free</p>:pl.period==="custom"?<p style={{fontSize:14,fontWeight:700,color:pl.color}}>Custom</p>:<p style={{fontSize:16,fontWeight:800,color:pl.color}}>{money(pl.priceXAF,"XAF")}/mo</p>}
                </div>
              </div>
              <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                {PLAN_FEATURES[pl.id].slice(0,3).map((f,fi)=><span key={fi} style={{fontSize:10.5,color:"var(--t2)",background:"var(--cH)",padding:"2px 8px",borderRadius:20,border:"1px solid var(--b)"}}>{f}</span>)}
                {PLAN_FEATURES[pl.id].length>3&&<span style={{fontSize:10.5,color:"var(--t3)",padding:"2px 8px"}}>+{PLAN_FEATURES[pl.id].length-3} more</span>}
              </div>
            </div>
          ))}
        </div>
      </div>}

      {/* Error */}
      {err&&step>0&&<p className="aFI" style={{fontSize:12,color:"var(--er)",fontWeight:600,marginTop:12}}>{err}</p>}
    </div>
  </div>

  {/* Footer nav */}
  <div style={{padding:"16px 24px",borderTop:"1px solid var(--b)",display:"flex",justifyContent:"space-between",alignItems:"center",background:"var(--p)",flexShrink:0}}>
    <Btn v="gh" onClick={back} disabled={step===0}>← Back</Btn>
    <div style={{display:"flex",alignItems:"center",gap:12}}>
      {step===TOTAL-1&&<div style={{fontSize:12,color:"var(--t2)"}}>Plan: <strong style={{color:selectedPlanObj.color}}>{selectedPlanObj.label}</strong></div>}
      <Btn onClick={next} disabled={busy} sz="lg">
        {busy?<><Spinner/>Creating your business...</>:step===TOTAL-1?("🚀 "+tr.launch):"Continue →"}
      </Btn>
    </div>
  </div>
</div>

);
};

// ═════════════════════════════════════════════════════════════════════════════
// WELCOME SCREEN
// ═════════════════════════════════════════════════════════════════════════════
const WelcomeAnim = ({user, biz, onDone, soundOn}) => {
const [phase,setPhase] = useState(0);
useEffect(()=>{
if(soundOn) SFX.welcome();
const t1=setTimeout(()=>setPhase(1),300);
const t2=setTimeout(()=>setPhase(2),1100);
const t3=setTimeout(()=>setPhase(3),2100);
const t4=setTimeout(()=>onDone(),3800);
return()=>{ clearTimeout(t1);clearTimeout(t2);clearTimeout(t3);clearTimeout(t4); };
},[]);
return (
<div style={{position:"fixed",inset:0,background:"var(-bg)",zIndex:9999,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",overflow:"hidden"}}>
{phase>=2&&Array.from({length:18}).map((_,i)=>{
const x=(Math.random()-.5)*340,y=(Math.random()-.5)*340;
const c=["var(-ac)","var(-ac2)","var(-ok)","var(-wn)"][i%4];
return <div key={i} style={{position:"absolute",top:"50%",left:"50%",width:9,height:9,borderRadius:2,background:c,opacity:0,animation:`confetti ${.6+Math.random()*.9}s ease-out both`,animationDelay:(Math.random()*.25)+"s",transform:`translate(${x}px,${y}px)`}}/>;
})}
<div style={{textAlign:"center",animation:phase>=1?"wIn .6s cubic-bezier(.22,1,.36,1) both":"none",opacity:phase<1?0:1}}>
<div style={{fontSize:64,marginBottom:18,animation:"floatY 2s ease-in-out infinite"}}>⬡</div>
<h1 style={{fontSize:38,fontWeight:900,letterSpacing:"-2px",lineHeight:1,marginBottom:8}}>
<span className="gtext">Lekoev</span><span style={{color:"var(-t1)"}}>·BOS</span>
</h1>
{phase>=2&&<div className="aFU" style={{marginBottom:8}}>
<p style={{fontSize:16,color:"var(-t2)"}}>{tr&&tr.welcomeTo||"Welcome to"} <strong style={{color:"var(-t1)"}}>{biz||"Lekoev BOS"}</strong></p>
<p style={{fontSize:14,color:"var(-t3)",marginTop:4}}>👋 Hey {user}, you're all set!</p>
</div>}
{phase>=3&&<p className="aFU d2" style={{fontSize:11,color:"var(-t3)",fontWeight:700,textTransform:"uppercase",letterSpacing:"2px"}}>Loading workspace...</p>}
</div>
{phase>=3&&<div className="aFU d3" style={{position:"absolute",bottom:"14%",width:220,height:3,borderRadius:2,background:"var(-b)",overflow:"hidden"}}>
<div style={{height:"100%",background:"linear-gradient(90deg,var(-ac),var(-ac2))",borderRadius:2,animation:"pBar 1.3s ease both"}}/>
</div>}
</div>
);
};

// ═════════════════════════════════════════════════════════════════════════════
// MAIN APP - Full dashboard with all modules
// ═════════════════════════════════════════════════════════════════════════════

// ── Dashboard ─────────────────────────────────────────────────────────────
const Dashboard = () => {
const {tr,cur,setPage,soundOn} = useApp();
const h = new Date().getHours();
const greet = h<12?tr.greet0:h<17?tr.greet1:tr.greet2;
const KC = ["var(-ac)","var(-er)","var(-ok)","var(-ac2)"];
const KB = ["ac","er","ok","pu"];
return (
<div className="aFU" style={{display:"flex",flexDirection:"column",gap:18}}>
<div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",flexWrap:"wrap",gap:12}}>
<div>
<div style={{display:"flex",alignItems:"center",gap:10,marginBottom:6}}><LiveDot/><span style={{fontSize:11,color:"var(-t3)",fontWeight:500}}>{new Date().toLocaleDateString("en-GB",{weekday:"long",day:"numeric",month:"long",year:"numeric"})}</span></div>
<h1 style={{fontSize:24,fontWeight:900,letterSpacing:"-.6px",lineHeight:1.15}}>{greet}, <span className="gtext">Lekoev</span> 👋</h1>
<p style={{fontSize:12,color:"var(-t2)",marginTop:4}}>Lekoev Enterprises · Limbe, Cameroon</p>
</div>
<div style={{display:"flex",gap:8}}>
<Btn v="sol" sz="sm" onClick={()=>{if(soundOn)SFX.tap();setPage("transactions");}}>+ Transaction</Btn>
<Btn sz="sm" onClick={()=>{if(soundOn)SFX.tap();setPage("ai");}}>✦ {tr.askAI}</Btn>
</div>
</div>

  {/* KPIs */}
  <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(160px,1fr))",gap:12}}>
    {D.kpis.map((k,i)=>(
      <Card key={i} hov className={"aFU d"+(i+1)} style={{padding:"16px 18px"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
          <p style={{fontSize:10,fontWeight:700,color:"var(--t2)",textTransform:"uppercase",letterSpacing:"1.2px"}}>{tr[k.k]||k.k}</p>
          <div style={{width:30,height:30,borderRadius:8,flexShrink:0,background:"rgba(var(--ar),.1)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,color:"var(--ac)",fontWeight:900}}>{k.icon}</div>
        </div>
        <p className="mono" style={{fontSize:i===3?24:19,fontWeight:700,color:"var(--t1)",letterSpacing:"-1px",marginBottom:12,lineHeight:1}}>
          {i===3?<Counter to={k.v}/>:money(k.v,cur)}
        </p>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end"}}>
          <Spark vals={k.sp} color={KC[i]} w={72} h={26}/>
          <Badge c={KB[i]}>{k.ch>0?"▲":"▼"} {Math.abs(k.ch)}%</Badge>
        </div>
      </Card>
    ))}
  </div>

  {/* Charts */}
  <div style={{display:"grid",gridTemplateColumns:"minmax(0,1.45fr) minmax(0,1fr)",gap:12}} className="mg1">
    <Card className="aFU d5">
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
        <div><p style={{fontSize:13,fontWeight:700,color:"var(--t1)"}}>{tr.cashFlow}</p><p style={{fontSize:11,color:"var(--t2)"}}>7-month overview</p></div>
        <div style={{display:"flex",gap:10,fontSize:10,color:"var(--t3)"}}><span><span style={{color:"var(--ac)"}}>■</span> {tr.income}</span><span><span style={{color:"var(--er)"}}>■</span> {tr.expenses}</span></div>
      </div>
      <BarChart data={D.flow}/>
    </Card>
    <Card className="aFU d6">
      <p style={{fontSize:13,fontWeight:700,color:"var(--t1)",marginBottom:14}}>{tr.health}</p>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
        {[{l:tr.profitMargin,p:74,c:"var(--ok)"},{l:"Retention",p:88,c:"var(--ac)"},{l:"Cash Ratio",p:92,c:"var(--wn)"},{l:"Growth",p:61,c:"var(--ac2)"}].map((m,i)=>(
          <div key={i} style={{display:"flex",alignItems:"center",gap:8}}>
            <div style={{position:"relative",flexShrink:0}}>
              <Donut pct={m.p} color={m.c} size={50}/>
              <span className="mono" style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:700,color:m.c}}>{m.p}%</span>
            </div>
            <p style={{fontSize:10.5,color:"var(--t2)",lineHeight:1.3,fontWeight:500}}>{m.l}</p>
          </div>
        ))}
      </div>
    </Card>
  </div>

  {/* Recent txns */}
  <Card style={{padding:0}} className="aFU d7">
    <div style={{padding:"15px 18px 10px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
      <p style={{fontSize:13,fontWeight:700,color:"var(--t1)"}}>{tr.recentTxns}</p>
      <Btn v="gh" sz="xs" onClick={()=>setPage("transactions")}>{tr.viewAll} →</Btn>
    </div>
    <Dv/>
    <div style={{padding:"6px 8px 10px"}}>
      {D.txns.map((tx,i)=>(
        <div key={i} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 10px",borderRadius:9,transition:"background .15s",cursor:"default"}} onMouseEnter={e=>e.currentTarget.style.background="var(--cH)"} onMouseLeave={e=>e.currentTarget.style.background=""}>
          <div style={{width:30,height:30,borderRadius:8,flexShrink:0,background:tx.t==="income"?"rgba(61,223,160,.1)":"rgba(255,92,124,.1)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,color:tx.t==="income"?"var(--ok)":"var(--er)",fontWeight:900}}>{tx.t==="income"?"↑":"↓"}</div>
          <div style={{flex:1,minWidth:0}}>
            <p style={{fontSize:12.5,fontWeight:500,color:"var(--t1)",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{tx.desc}</p>
            <p style={{fontSize:10,color:"var(--t3)",marginTop:1}}>{tx.date} · {tx.cat}</p>
          </div>
          <span className="mono" style={{fontSize:12,fontWeight:700,flexShrink:0,color:tx.t==="income"?"var(--ok)":"var(--er)"}}>{tx.t==="income"?"+":"-"}{money(tx.amt,cur)}</span>
        </div>
      ))}
    </div>
  </Card>
</div>

);
};

// ── Transactions ──────────────────────────────────────────────────────────
const TxPage = () => {
const {tr,cur,soundOn} = useApp();
const [txns,setTxns] = useState(D.txns);
const [flt,setFlt] = useState("all");
const [q,setQ] = useState("");
const [open,setOpen] = useState(false);
const [form,setForm] = useState({desc:"",amt:"",t:"income",cat:"Revenue",date:new Date().toISOString().split("T")[0]});
const CATS = ["Revenue","Operations","Admin","Marketing","Utilities","Payroll","Other"];
const add = () => {
if(!form.desc||!form.amt) return;
setTxns([{id:"TXN-"+String(txns.length+1).padStart(3,"0"),date:form.date,desc:form.desc,cat:form.cat,amt:+form.amt,t:form.t},...txns]);
if(soundOn) SFX.coin();
setOpen(false);
setForm({desc:"",amt:"",t:"income",cat:"Revenue",date:new Date().toISOString().split("T")[0]});
};
const fil = txns.filter(tx=>(flt==="all"||tx.t===flt)&&(!q||tx.desc.toLowerCase().includes(q.toLowerCase())||tx.cat.toLowerCase().includes(q.toLowerCase())));
const tIn = txns.filter(t=>t.t==="income").reduce((s,t)=>s+t.amt,0);
const tOut = txns.filter(t=>t.t==="expense").reduce((s,t)=>s+t.amt,0);
return (
<div className="aFU" style={{display:"flex",flexDirection:"column",gap:16}}>
<SHd title={tr.transactions} sub={txns.length+" records · live ledger"} end={<Btn sz="sm" onClick={()=>{if(soundOn)SFX.tap();setOpen(!open);}}>+ {tr.addNew.replace("+ ","")}</Btn>}/>
<div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10}} className="mg1">
{[[tr.revenue,tIn,"var(-ok)"],[tr.expenses,tOut,"var(-er)"],[tr.netProfit,tIn-tOut,"var(-ac)"]].map(([l,v,c],i)=>(
<Card key={i} style={{padding:"12px 16px"}}><p style={{fontSize:10,fontWeight:700,color:"var(-t2)",textTransform:"uppercase",letterSpacing:1,marginBottom:5}}>{l}</p><p className="mono" style={{fontSize:15,fontWeight:700,color:c}}>{money(v,cur)}</p></Card>
))}
</div>
{open&&<Card glow className="aSI" style={{padding:"18px 20px"}}>
<p style={{fontSize:14,fontWeight:800,color:"var(-t1)",marginBottom:14}}>New Transaction</p>
<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
<div style={{gridColumn:"1/-1"}}><label style={{fontSize:11,color:"var(-t2)",display:"block",marginBottom:5}}>{tr.description}</label><input value={form.desc} onChange={e=>setForm({...form,desc:e.target.value})} placeholder="e.g. Client Payment"/></div>
<div><label style={{fontSize:11,color:"var(-t2)",display:"block",marginBottom:5}}>{tr.amount}</label><input type="number" value={form.amt} onChange={e=>setForm({...form,amt:e.target.value})} placeholder="0"/></div>
<div><label style={{fontSize:11,color:"var(-t2)",display:"block",marginBottom:5}}>{tr.date}</label><input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></div>
<div><label style={{fontSize:11,color:"var(-t2)",display:"block",marginBottom:5}}>{tr.type}</label><select value={form.t} onChange={e=>setForm({...form,t:e.target.value})}><option value="income">{tr.income}</option><option value="expense">{tr.expense}</option></select></div>
<div><label style={{fontSize:11,color:"var(-t2)",display:"block",marginBottom:5}}>{tr.category}</label><select value={form.cat} onChange={e=>setForm({...form,cat:e.target.value})}>{CATS.map(c=><option key={c}>{c}</option>)}</select></div>
</div>
<div style={{display:"flex",gap:8,marginTop:14}}><Btn onClick={add}>{tr.save}</Btn><Btn v="gh" onClick={()=>setOpen(false)}>{tr.cancel}</Btn></div>
</Card>}
<div style={{display:"flex",gap:7,flexWrap:"wrap",alignItems:"center"}}>
{[["all",tr.all],["income",tr.income],["expense",tr.expense]].map(([f,l])=><Btn key={f} v={flt===f?"pri":"gh"} sz="sm" onClick={()=>setFlt(f)}>{l}</Btn>)}
<div style={{position:"relative",flex:1,minWidth:150,maxWidth:260}}><span style={{position:"absolute",left:10,top:"50%",transform:"translateY(-50%)",color:"var(-t3)",fontSize:12,pointerEvents:"none"}}>⌕</span><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search..." style={{paddingLeft:28,height:34}}/></div>
<Btn v="sol" sz="sm">↓ CSV</Btn>
</div>
<Card style={{padding:0,overflow:"hidden"}}>
<div style={{overflowX:"auto"}}>
<table style={{width:"100%",borderCollapse:"collapse",minWidth:520}}>
<thead><tr style={{borderBottom:"1px solid var(-b)"}}>{["ID","Date","Description","Category","Type","Amount"].map(h=><th key={h} style={{padding:"10px 14px",textAlign:"left",fontSize:9.5,color:"var(-t3)",textTransform:"uppercase",letterSpacing:"1.2px",fontWeight:700,whiteSpace:"nowrap"}}>{h}</th>)}</tr></thead>
<tbody>{fil.length===0?<tr><td colSpan={6} style={{padding:36,textAlign:"center",color:"var(-t3)"}}>{tr.noResults}</td></tr>:fil.map((tx,i)=>(
<tr key={i} style={{borderBottom:"1px solid var(-b)",transition:"background .14s"}} onMouseEnter={e=>e.currentTarget.style.background="var(-cH)"} onMouseLeave={e=>e.currentTarget.style.background=""}>
<td style={{padding:"10px 14px"}}><span className="mono" style={{fontSize:10,color:"var(-t3)"}}>{tx.id}</span></td>
<td style={{padding:"10px 14px"}}><span style={{fontSize:11,color:"var(-t2)",whiteSpace:"nowrap"}}>{tx.date}</span></td>
<td style={{padding:"10px 14px",maxWidth:220}}><span style={{fontSize:12.5,color:"var(-t1)",display:"block",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{tx.desc}</span></td>
<td style={{padding:"10px 14px"}}><Badge>{tx.cat}</Badge></td>
<td style={{padding:"10px 14px"}}><Badge c={tx.t==="income"?"ok":"er"}>{tx.t==="income"?tr.income:tr.expense}</Badge></td>
<td style={{padding:"10px 14px"}}><span className="mono" style={{fontSize:12,fontWeight:700,color:tx.t==="income"?"var(-ok)":"var(-er)",whiteSpace:"nowrap"}}>{tx.t==="income"?"+":"-"}{money(tx.amt,cur)}</span></td>
</tr>
))}</tbody>
</table>
</div>
</Card>
</div>
);
};

// ── Clients ───────────────────────────────────────────────────────────────
const ClientsPage = () => {
const {tr,cur} = useApp();
const MRR = D.clients.filter(c=>c.s==="active").reduce((s,c)=>s+c.mrr,0);
return (
<div className="aFU" style={{display:"flex",flexDirection:"column",gap:16}}>
<SHd title={tr.clients} sub="Subscriptions, renewals & MRR" end={<Btn sz="sm">+ {tr.addNew.replace("+ ","")}</Btn>}/>
<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(110px,1fr))",gap:10}}>
{[{l:"Total",v:D.clients.length,c:"var(-t1)"},{l:tr.active,v:D.clients.filter(c=>c.s==="active").length,c:"var(-ok)"},{l:tr.trial,v:D.clients.filter(c=>c.s==="trial").length,c:"var(-wn)"},{l:tr.mrr,v:money(MRR,cur),c:"var(-ac)",r:true},{l:tr.arr,v:money(MRR*12,cur),c:"var(-ac2)",r:true}].map((s,i)=>(
<Card key={i} style={{padding:"12px 14px"}}><p style={{fontSize:9.5,fontWeight:700,color:"var(-t2)",textTransform:"uppercase",letterSpacing:1,marginBottom:5}}>{s.l}</p><p className="mono" style={{fontSize:s.r?13:20,fontWeight:700,color:s.c}}>{s.v}</p></Card>
))}
</div>
<div style={{display:"flex",flexDirection:"column",gap:10}}>
{D.clients.map((c,i)=>{
const days=Math.ceil((new Date(c.r)-new Date())/86400000);
const urg=days<30?"er":days<60?"wn":"ok";
return <Card key={i} hov className={"aFU d"+Math.min(i+1,6)} style={{padding:"14px 18px"}}>
<div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
<div style={{display:"flex",alignItems:"center",gap:10}}>
<div style={{width:38,height:38,borderRadius:10,flexShrink:0,background:"rgba(var(-ar),.1)",border:"1px solid rgba(var(-ar),.2)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,fontWeight:900,color:"var(-ac)"}}>{c.n[0]}</div>
<div><p style={{fontSize:13,fontWeight:700,color:"var(-t1)"}}>{c.n}</p><p style={{fontSize:11,color:"var(-t2)"}}>{c.p} · {c.city}</p></div>
</div>
<div style={{display:"flex",alignItems:"center",gap:10,flexWrap:"wrap"}}>
<div style={{textAlign:"right"}}><p style={{fontSize:9,color:"var(-t3)",textTransform:"uppercase",letterSpacing:1}}>{tr.mrr}</p><p className="mono" style={{fontSize:12.5,fontWeight:700,color:"var(-ok)"}}>{money(c.mrr,cur)}</p></div>
<div style={{textAlign:"right"}}><p style={{fontSize:9,color:"var(-t3)",textTransform:"uppercase",letterSpacing:1}}>{tr.renewal}</p><p style={{fontSize:11,color:"var(-t1)"}}>{c.r}</p></div>
<Badge c={urg}>{days}d</Badge>
<Badge c={c.s==="active"?"ok":"wn"}>{c.s==="active"?tr.active:tr.trial}</Badge>
</div>
</div>
</Card>;
})}
</div>
</div>
);
};

// ── Reports ───────────────────────────────────────────────────────────────
const ReportsPage = () => {
const {tr,cur} = useApp();
const [period,setPeriod] = useState("MTD");
const tIn=D.txns.filter(t=>t.t==="income").reduce((s,t)=>s+t.amt,0);
const tOut=D.txns.filter(t=>t.t==="expense").reduce((s,t)=>s+t.amt,0);
const net=tIn-tOut;
const cats=[{n:"Server & Cloud",p:47,a:57750},{n:"Internet",p:20,a:24600},{n:"Admin",p:14,a:17220},{n:"Marketing",p:11,a:13530},{n:"Other",p:8,a:9840}];
const cc=["var(-ac)","var(-ok)","var(-wn)","var(-ac2)","var(-t3)"];
return (
<div className="aFU" style={{display:"flex",flexDirection:"column",gap:16}}>
<SHd title={tr.reports} sub="P&L · Cash flow · Insights" end={<><div style={{display:"flex",gap:5}}>{["MTD","QTD","YTD"].map(p=><Btn key={p} v={period===p?"pri":"gh"} sz="sm" onClick={()=>setPeriod(p)}>{p}</Btn>)}</div><Btn v="sol" sz="sm">↓ PDF</Btn></>}/>
<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}} className="mg1">
<Card>
<p style={{fontSize:13,fontWeight:700,color:"var(-t1)",marginBottom:14}}>P&L - {period}</p>
<div style={{display:"flex",flexDirection:"column",gap:9}}>
{[{l:"Gross Revenue",v:tIn,c:"var(-ok)"},{l:"Operating Costs",v:-tOut*.62,c:"var(-er)"},{l:"Gross Profit",v:tIn-tOut*.62,c:"var(-t1)"},null,{l:"Other Expenses",v:-tOut*.38,c:"var(-er)"},{l:"Net Profit",v:net,c:"var(-ac)",bold:true},{l:tr.profitMargin,v:((net/tIn)*100).toFixed(1)+"%",c:"var(-ac2)",raw:true}].map((row,i)=>row===null?<div key={i} style={{borderTop:"1px solid var(-b)",margin:"2px 0"}}/>:(
<div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
<span style={{fontSize:12,color:"var(-t2)"}}>{row.l}</span>
<span className="mono" style={{fontSize:12,fontWeight:row.bold?700:500,color:row.c}}>{row.raw?row.v:(row.v>=0?"+":"")+money(Math.abs(row.v),cur)}</span>
</div>
))}
</div>
</Card>
<Card>
<p style={{fontSize:13,fontWeight:700,color:"var(-t1)",marginBottom:14}}>{tr.cashFlow}</p>
<BarChart data={D.flow}/>
<div style={{marginTop:12,display:"flex",flexDirection:"column",gap:7}}>
{D.flow.slice(-3).reverse().map((m,i)=>(
<div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
<span style={{fontSize:11,color:"var(-t2)"}}>{m.m} 2026</span>
<div style={{display:"flex",gap:12}}>
<span className="mono" style={{fontSize:10.5,color:"var(-ok)"}}>+{money(m.i*1000,cur)}</span>
<span className="mono" style={{fontSize:10.5,color:"var(-er)"}}>-{money(m.e*1000,cur)}</span>
</div>
</div>
))}
</div>
</Card>
</div>
<Card>
<p style={{fontSize:13,fontWeight:700,color:"var(-t1)",marginBottom:14}}>{tr.expBreakdown}</p>
<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))",gap:10}}>
{cats.map((c,i)=>(
<div key={i} style={{padding:"12px 14px",borderRadius:10,background:"var(-cH)",border:"1px solid var(-b)"}}>
<div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}><span style={{fontSize:11.5,color:"var(-t2)",fontWeight:500}}>{c.n}</span><span style={{fontSize:11,fontWeight:700,color:cc[i]}}>{c.p}%</span></div>
<div style={{height:3,background:"var(-b)",borderRadius:2,overflow:"hidden"}}><div style={{height:"100%",width:c.p+"%",background:cc[i],borderRadius:2,transition:"width 1s ease"}}/></div>
<p className="mono" style={{fontSize:11,color:"var(-t2)",marginTop:7}}>{money(c.a,cur)}</p>
</div>
))}
</div>
</Card>
</div>
);
};

// ── Invoices ──────────────────────────────────────────────────────────────
const InvoicesPage = () => {
const {tr,cur,soundOn} = useApp();
const [invs,setInvs] = useState(D.invoices);
const sv={pending:"wn",paid:"ok",overdue:"er",draft:"def"};
const st={pending:tr.pending,paid:tr.paid,overdue:tr.overdue,draft:tr.draft};
return (
<div className="aFU" style={{display:"flex",flexDirection:"column",gap:16}}>
<SHd title={tr.invoices} sub="Create, send & track" end={<Btn sz="sm">+ New Invoice</Btn>}/>
<div style={{display:"flex",flexDirection:"column",gap:10}}>
{invs.map((inv,i)=>(
<Card key={i} hov className={"aFU d"+Math.min(i+1,5)} style={{padding:"14px 18px"}}>
<div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
<div style={{display:"flex",alignItems:"center",gap:10}}>
<div style={{width:36,height:36,borderRadius:9,background:"var(-cH)",border:"1px solid var(-bH)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0}}>📄</div>
<div><p className="mono" style={{fontSize:11,color:"var(-ac)",fontWeight:600,marginBottom:2}}>{inv.id}</p><p style={{fontSize:13,color:"var(-t1)"}}>{inv.client}</p></div>
</div>
<div style={{display:"flex",alignItems:"center",gap:10,flexWrap:"wrap"}}>
<span className="mono" style={{fontSize:14,fontWeight:700,color:"var(-t1)"}}>{money(inv.amt,cur)}</span>
<span style={{fontSize:11,color:"var(-t2)"}}>Due {inv.due}</span>
<Badge c={sv[inv.s]}>{st[inv.s]||inv.s}</Badge>
{inv.s!=="paid"&&<Btn v="ok" sz="xs" onClick={()=>{if(soundOn)SFX.coin();setInvs(is=>is.map(x=>x.id===inv.id?{...x,s:"paid"}:x));}}>✓ Mark Paid</Btn>}
</div>
</div>
</Card>
))}
</div>
</div>
);
};

// ── Inventory ─────────────────────────────────────────────────────────────
const InventoryPage = () => {
const {tr,cur} = useApp();
return (
<div className="aFU" style={{display:"flex",flexDirection:"column",gap:16}}>
<SHd title={tr.inventory} sub="Products & catalog" end={<Btn sz="sm">+ Add Product</Btn>}/>
<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(205px,1fr))",gap:12}}>
{D.products.map((p,i)=>(
<Card key={i} hov className={"aFU d"+Math.min(i+1,6)} style={{padding:"16px 18px"}}>
<div style={{display:"flex",justifyContent:"space-between",marginBottom:12}}>
<div style={{width:36,height:36,borderRadius:9,background:"rgba(var(-ar),.1)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>📦</div>
<Badge c={p.s==="active"?"ok":"def"}>{p.s==="active"?tr.active:tr.draft}</Badge>
</div>
<p style={{fontSize:13,fontWeight:700,color:"var(-t1)",marginBottom:3}}>{p.n}</p>
<p className="mono" style={{fontSize:10,color:"var(-t3)",marginBottom:12}}>{p.sku}</p>
<div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
<span className="mono" style={{fontSize:15,fontWeight:700,color:"var(-ac)"}}>{money(p.price,cur)}</span>
<div style={{display:"flex",gap:6}}><Btn v="gh" sz="xs">Edit</Btn><Btn v="sol" sz="xs">Sell</Btn></div>
</div>
</Card>
))}
</div>
</div>
);
};

// ── Payroll ───────────────────────────────────────────────────────────────
const PayrollPage = () => {
const {tr,cur,soundOn} = useApp();
const total = D.employees.reduce((s,e)=>s+e.salary,0);
return (
<div className="aFU" style={{display:"flex",flexDirection:"column",gap:16}}>
<SHd title={tr.payroll} sub="Employee salaries & payslips" end={<Btn sz="sm" onClick={()=>soundOn&&SFX.success()}>{tr.runPayroll}</Btn>}/>
<Card style={{padding:"14px 18px"}}><p style={{fontSize:10,fontWeight:700,color:"var(-t2)",textTransform:"uppercase",letterSpacing:"1.2px",marginBottom:5}}>Total Monthly Payroll</p><p className="mono" style={{fontSize:22,fontWeight:700,color:"var(-ac)"}}>{money(total,cur)}</p></Card>
<div style={{display:"flex",flexDirection:"column",gap:10}}>
{D.employees.map((e,i)=>(
<Card key={i} hov className={"aFU d"+Math.min(i+1,4)} style={{padding:"14px 18px"}}>
<div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
<div style={{display:"flex",alignItems:"center",gap:10}}>
<div style={{width:36,height:36,borderRadius:"50%",flexShrink:0,background:"rgba(var(-ar),.1)",border:"1.5px solid rgba(var(-ar),.25)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:900,color:"var(-ac)"}}>{e.n.split(" ").map(x=>x[0]).join("").slice(0,2)}</div>
<div><p style={{fontSize:13,fontWeight:700,color:"var(-t1)"}}>{e.n}</p><p style={{fontSize:11,color:"var(-t2)"}}>{e.role}</p></div>
</div>
<div style={{display:"flex",alignItems:"center",gap:10}}>
<span className="mono" style={{fontSize:13,fontWeight:700,color:"var(-ok)"}}>{money(e.salary,cur)}/mo</span>
<Badge c="ok">{tr.active}</Badge>
<Btn v="gh" sz="xs">📄 Payslip</Btn>
</div>
</div>
</Card>
))}
</div>
</div>
);
};

// ── AI ────────────────────────────────────────────────────────────────────
const AIPage = () => {
const {tr,cur,soundOn} = useApp();
const [msgs,setMsgs] = useState(D.aiSeed);
const [inp,setInp] = useState("");
const [busy,setBusy] = useState(false);
const [mic,setMic] = useState(false);
const endRef = useRef(null);
useEffect(()=>{ endRef.current?.scrollIntoView({behavior:"smooth"}); },[msgs]);

const SMART = {
profit:  ()=>"📊 **Profit Summary (MTD)**\n\n• Revenue: "+money(4820000,cur)+"\n• Expenses: "+money(1230000,cur)+"\n• Net Profit: "+money(3590000,cur)+"\n• Margin: 74% ✅ (+23.1% vs last month)",
revenue: ()=>"💰 **Top Revenue Sources**\n\n1. OHADA Pro - "+money(850000,cur)+"\n2. Gumroad Sales - "+money(320000,cur)+"\n3. Etsy Manager - "+money(180000,cur)+"\n4. Pharmacy License - "+money(150000,cur)+"\n5. Restaurant License - "+money(120000,cur),
renew:   ()=>"⚠️ **Upcoming Renewals**\n\n🔴 Mini Supermarche - 17 days (May 20)\n🟡 Brocante Limbe - 57 days\n🟡 Restaurant - 72 days\n🟢 Pharmacie - 89 days\n\n⚡ Call Mini Supermarche today!",
health:  ()=>"💚 **Business Health: 87/100**\n\n✅ Profit Margin: 74%\n✅ Client Retention: 88%\n✅ Cash Ratio: 92%\n✅ Growth: +23.1% MTD\n✅ MRR: "+money(87000,cur)+"\n\nRunning strong, Lekoev!",
clients: ()=>"👥 **Client Overview**\n\n• Total: 6 | Active: 5 | Trial: 1 ⚠️\n• MRR: "+money(117000,cur)+"\n• ARR: "+money(1404000,cur)+"\n• Top client: Tech Startup ("+money(45000,cur)+"/mo)",
invoice: ()=>"📄 **Invoice Status**\n\n• Pending: 2 - "+money(185000,cur)+"\n• Paid: 1 - "+money(75000,cur)+"\n• ⚠️ Overdue: Clinique ("+money(90000,cur)+")\n• Draft: 1 - Mini Supermarche",
payroll: ()=>"💼 **Payroll Summary**\n\n• Monthly total: "+money(570000,cur)+"\n• 4 employees active\n• Top earner: "+money(200000,cur)+"/mo",
expense: (t)=>{ const m=t.match(/(\d+)/); return "✅ **Expense Logged**\n\n• Amount: "+money(m?+m[1]:0,cur)+"\n• Category: Operations\n• Date: "+new Date().toLocaleDateString("en-GB")+"\n• Ref: TXN-"+Math.floor(Math.random()*900+100)+"\n\nSaved to your ledger."; },
};
const sMatch = t => {
const l=t.toLowerCase();
if(/profit|p&l|gain/.test(l)) return SMART.profit();
if(/revenue|source|income/.test(l)) return SMART.revenue();
if(/renew|expir/.test(l)) return SMART.renew();
if(/health|score|overview|summary/.test(l)) return SMART.health();
if(/client|mrr|subscription/.test(l)) return SMART.clients();
if(/invoice|facture|bill/.test(l)) return SMART.invoice();
if(/payroll|salary|paie/.test(l)) return SMART.payroll();
if(/(add|log|record).*\d+/.test(l)) return SMART.expense(t);
return null;
};
const fallbacks = ["Revenue "+money(4820000,cur)+", Net Profit "+money(3590000,cur)+" (74% margin). Mini Supermarche trial ends in 17 days. What else?","Business health 87/100. MRR at "+money(87000,cur)+", +23.1% growth. What do you need?","Your top earner: OHADA Accounting Pro at "+money(850000,cur)+". Retention at 88%. How can I help?"];
const send = useCallback(async t => {
if(!t.trim()) return;
setMsgs(m=>[...m,{r:"user",t}]);
setInp(""); setBusy(true);
if(soundOn) SFX.tap();
const sr=sMatch(t);
if(sr){ await new Promise(r=>setTimeout(r,400+Math.random()*300)); if(soundOn)SFX.notify(); setMsgs(m=>[...m,{r:"assistant",t:sr}]); setBusy(false); return; }
try{
const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:700,system:"You are the AI Business Assistant for Lekoev Enterprises - a tech/Excel tools business in Limbe, Cameroon. Revenue MTD: "+money(4820000,cur)+", Net Profit: "+money(3590000,cur)+", 47 clients, MRR: "+money(87000,cur)+". Be sharp and concise. Max 3 sentences unless breakdown requested.",messages:[...msgs.filter(m=>m.r!=="system").slice(-6).map(m=>({role:m.r,content:m.t})),{role:"user",content:t}]})});
if(!res.ok) throw new Error();
const data=await res.json();
const reply=data.content?.[0]?.text;
if(!reply) throw new Error();
if(soundOn) SFX.notify();
setMsgs(m=>[...m,{r:"assistant",t:reply}]);
}catch{ await new Promise(r=>setTimeout(r,300)); if(soundOn)SFX.notify(); setMsgs(m=>[...m,{r:"assistant",t:fallbacks[Math.floor(Math.random()*fallbacks.length)]}]); }
setBusy(false);
},[msgs,cur,soundOn]);

const startMic = () => {
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(!SR){ setMsgs(m=>[...m,{r:"assistant",t:"🎤 Voice needs Chrome browser. Type instead!"}]); return; }
const r=new SR(); r.lang="en-US"; r.continuous=false;
r.onresult=e=>{const t=e.results[0][0].transcript;setInp(t);setMic(false);send(t);};
r.onerror=()=>{setMic(false);setMsgs(m=>[...m,{r:"assistant",t:"🎤 Mic access needed. Type instead!"}]);};
r.onend=()=>setMic(false); r.start(); setMic(true);
};

const quick=["Show profit summary","Clients renewing soon?","Add expense 25000 internet","Business health","Invoice status","Payroll summary","Top revenue sources"];

return (
<div className="aFU" style={{display:"flex",flexDirection:"column",gap:12,height:"calc(100vh - 170px)",minHeight:400}}>
<div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}}>
<div><h2 style={{fontSize:19,fontWeight:800,color:"var(-t1)"}}>✦ {tr.ai}</h2><p style={{fontSize:12,color:"var(-t2)",marginTop:2}}>Voice & text · Real-time · Always-on</p></div>
<Badge c="ok"><span style={{display:"inline-block",width:5,height:5,borderRadius:"50%",background:"var(-ok)",animation:"pulse 2s infinite",marginRight:4}}/>Online · Never errors</Badge>
</div>
<div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
{quick.map((q,i)=><button key={i} onClick={()=>send(q)} style={{padding:"5px 11px",borderRadius:20,fontSize:11,fontWeight:600,background:"var(-c)",border:"1px solid var(-bH)",color:"var(-t2)",cursor:"pointer",transition:"all .15s"}} onMouseEnter={e=>{e.target.style.borderColor="var(-ac)";e.target.style.color="var(-ac)";}} onMouseLeave={e=>{e.target.style.borderColor="var(-bH)";e.target.style.color="var(-t2)";}}>{q}</button>)}
</div>
<Card style={{flex:1,overflowY:"auto",padding:"14px 16px",display:"flex",flexDirection:"column",gap:12}}>
{msgs.map((m,i)=>(
<div key={i} style={{display:"flex",gap:8,flexDirection:m.r==="user"?"row-reverse":"row",animation:"fadeUp .28s ease both"}}>
<div style={{width:28,height:28,borderRadius:"50%",flexShrink:0,background:m.r==="user"?"var(-ac)":"var(-cH)",border:"1px solid "+(m.r==="user"?"var(-ac)":"var(-bH)"),display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:900,color:m.r==="user"?"var(-bg)":"var(-t2)"}}>{m.r==="user"?"LK":"✦"}</div>
<div style={{maxWidth:"78%",padding:"10px 14px",whiteSpace:"pre-wrap",borderRadius:m.r==="user"?"14px 4px 14px 14px":"4px 14px 14px 14px",background:m.r==="user"?"rgba(var(-ar),.12)":"var(-cH)",border:"1px solid "+(m.r==="user"?"rgba(var(-ar),.25)":"var(-bH)"),fontSize:13,lineHeight:1.65,color:"var(-t1)"}}>{m.t}</div>
</div>
))}
{busy&&<div style={{display:"flex",gap:8}}><div style={{width:28,height:28,borderRadius:"50%",background:"var(-cH)",border:"1px solid var(-bH)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,color:"var(-t2)"}}>✦</div><div style={{padding:"10px 14px",borderRadius:"4px 14px 14px 14px",background:"var(-cH)",border:"1px solid var(-bH)",display:"flex",gap:5,alignItems:"center"}}>{[0,1,2].map(j=><div key={j} style={{width:5,height:5,borderRadius:"50%",background:"var(-ac)",animation:`bounce3 1.2s ${j*.15}s infinite`}}/>)}</div></div>}
<div ref={endRef}/>
</Card>
<div style={{display:"flex",gap:8}}>
<input value={inp} onChange={e=>setInp(e.target.value)} onKeyDown={e=>e.key==="Enter"&&!e.shiftKey&&send(inp)} placeholder="Ask anything or give a command..." style={{flex:1}}/>
<button onClick={startMic} style={{width:40,height:40,borderRadius:9,flexShrink:0,background:mic?"rgba(var(-ar),.15)":"var(-c)",border:"1.5px solid "+(mic?"var(-ac)":"var(-bH)"),color:mic?"var(-ac)":"var(-t2)",fontSize:16,cursor:"pointer",transition:"all .2s",display:"flex",alignItems:"center",justifyContent:"center"}}>{mic?"🔴":"🎤"}</button>
<Btn onClick={()=>send(inp)} disabled={!inp.trim()||busy} style={{height:40,minWidth:52}}>{busy?<Spinner/>:"→"}</Btn>
</div>
</div>
);
};

// ── Passkey Generator ─────────────────────────────────────────────────────
const PasskeyPage = () => {
const {tr,soundOn} = useApp();
const [keys,setKeys] = useState(()=>[makeKeyObj("pro","1Y",5,"Pharmacie Centrale"),makeKeyObj("free","trial",2,"Mini Supermarche"),makeKeyObj("enterprise","2Y",20,"Tech Startup Douala"),makeKeyObj("pro","6M",3,"Clinique Moderne")]);
const [form,setForm] = useState({tier:"pro",dur:"1Y",devs:3,tenant:""});
const [copied,setCopied] = useState(null);
const [filter,setFilter] = useState("all");
const TV={enterprise:"pu",pro:"ac",business:"gd",free:"def"};
const gen=()=>{const k=makeKeyObj(form.tier,form.dur,form.devs,form.tenant);setKeys(ks=>[k,...ks]);if(soundOn)SFX.success();};
const copyKey=(key,id)=>{ try{navigator.clipboard.writeText(key);}catch{} setCopied(id); if(soundOn)SFX.notify(); setTimeout(()=>setCopied(null),2000); };
const revokeKey=(id)=>{ setKeys(ks=>ks.map(k=>k.id===id?{...k,status:"revoked"}:k)); if(soundOn)SFX.error(); };
const fil=keys.filter(k=>filter==="all"||k.status===filter);
return (
<div className="aFU" style={{display:"flex",flexDirection:"column",gap:16}}>
<SHd title={tr.passkeyGen} sub="Generate, distribute & manage license passkeys"/>
<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(110px,1fr))",gap:10}}>
{[{l:"Total Keys",v:keys.length,c:"var(-t1)"},{l:"Active",v:keys.filter(k=>k.status==="active").length,c:"var(-ok)"},{l:"Revoked",v:keys.filter(k=>k.status==="revoked").length,c:"var(-er)"},{l:"Total Uses",v:keys.reduce((s,k)=>s+k.activations,0),c:"var(-ac)"}].map((s,i)=>(
<Card key={i} style={{padding:"12px 14px"}}><p style={{fontSize:9.5,fontWeight:700,color:"var(-t2)",textTransform:"uppercase",letterSpacing:1,marginBottom:5}}>{s.l}</p><p className="mono" style={{fontSize:20,fontWeight:700,color:s.c}}><Counter to={s.v}/></p></Card>
))}
</div>
<Card glow style={{padding:20}}>
<p style={{fontSize:14,fontWeight:800,color:"var(-t1)",marginBottom:16}}>⚙ {tr.generate} Passkey</p>
<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}>
<div><label style={{fontSize:11,color:"var(-t2)",display:"block",marginBottom:5,fontWeight:700}}>{tr.licenseType}</label><select value={form.tier} onChange={e=>setForm(f=>({...f,tier:e.target.value}))}>{PLANS.map(p=><option key={p.id} value={p.id}>{p.label}</option>)}</select></div>
<div><label style={{fontSize:11,color:"var(-t2)",display:"block",marginBottom:5,fontWeight:700}}>Duration</label><select value={form.dur} onChange={e=>setForm(f=>({...f,dur:e.target.value}))}>{[["trial","Trial (15 days)"],["6M","6 Months"],["1Y","1 Year"],["2Y","2 Years"]].map(([v,l])=><option key={v} value={v}>{l}</option>)}</select></div>
<div><label style={{fontSize:11,color:"var(-t2)",display:"block",marginBottom:5,fontWeight:700}}>{tr.devicesAllowed}</label><input type="number" min={1} max={100} value={form.devs} onChange={e=>setForm(f=>({...f,devs:+e.target.value}))}/></div>
<div><label style={{fontSize:11,color:"var(-t2)",display:"block",marginBottom:5,fontWeight:700}}>Assign To (optional)</label><input value={form.tenant} onChange={e=>setForm(f=>({...f,tenant:e.target.value}))} placeholder="Client name"/></div>
</div>
<div style={{padding:"11px 14px",borderRadius:9,background:"var(-bg)",border:"1px solid var(-bH)",marginBottom:14}}>
<p style={{fontSize:9.5,color:"var(-t3)",fontWeight:700,textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>Format Preview</p>
<p className="mono" style={{fontSize:14,color:"var(-ac)",letterSpacing:"2px",fontWeight:600}}>LKV-{(form.tier==="free"?"FRE":form.tier==="pro"?"PRO":form.tier==="business"?"BIZ":"ENT").toUpperCase()}-2026-XXX-XXXX</p>
</div>
<Btn onClick={gen} sz="lg">⚡ {tr.generate} New Passkey</Btn>
</Card>
<div style={{display:"flex",gap:7}}>{[["all",tr.all],["active","Active"],["revoked","Revoked"]].map(([f,l])=><Btn key={f} v={filter===f?"pri":"gh"} sz="sm" onClick={()=>setFilter(f)}>{l}</Btn>)}</div>
<div style={{display:"flex",flexDirection:"column",gap:8}}>
{fil.map((k,i)=>{
const days=Math.ceil((new Date(k.expires)-new Date())/86400000);
const isCopied=copied===k.id;
return <Card key={k.id} className={"aFU d"+Math.min(i+1,6)} style={{padding:"13px 17px",opacity:k.status==="revoked"?.6:1}}>
<div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:10}}>
<div style={{flex:1,minWidth:0}}>
<div style={{display:"flex",alignItems:"center",gap:7,marginBottom:4,flexWrap:"wrap"}}>
<p className="mono" style={{fontSize:12.5,color:k.status==="revoked"?"var(-er)":"var(-ac)",fontWeight:700,letterSpacing:"1px"}}>{k.key}</p>
<Badge c={TV[k.tier]||"def"}>{k.tier.toUpperCase()}</Badge>
{k.status==="revoked"&&<Badge c="er">REVOKED</Badge>}
{k.status==="active"&&days<30&&<Badge c="wn">EXPIRING</Badge>}
</div>
<div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
<span style={{fontSize:11,color:"var(-t2)"}}>📱 {k.activations}/{k.devs} devices</span>
<span style={{fontSize:11,color:"var(-t2)"}}>Exp: {new Date(k.expires).toLocaleDateString()}</span>
{k.tenant&&<span style={{fontSize:11,color:"var(-t2)"}}>👤 {k.tenant}</span>}
{k.status==="active"&&<Badge c={days<30?"er":days<60?"wn":"ok"}>{days}d left</Badge>}
</div>
</div>
<div style={{display:"flex",gap:6,flexShrink:0}}>
<Btn v="sol" sz="xs" onClick={()=>copyKey(k.key,k.id)}>{isCopied?"✓ "+tr.copied:"📋 "+tr.copyKey}</Btn>
{k.status==="active"&&<Btn v="er" sz="xs" onClick={()=>revokeKey(k.id)}>{tr.revokeKey}</Btn>}
</div>
</div>
</Card>;
})}
</div>
</div>
);
};

// ── Settings ──────────────────────────────────────────────────────────────
const SettingsPage = ({user}) => {
const {tr,theme,setTheme,lang,setLang,cur,setCur,soundOn,setSoundOn,animOn,setAnimOn} = useApp();
const [cfg,setCfg] = useState({bizName:"Lekoev Enterprises",tz:"Africa/Douala",email:true,sms:false,twofa:false,backup:true});
const Sec=({title,children})=><Card style={{padding:"16px 20px"}}><p style={{fontSize:10.5,fontWeight:800,color:"var(-t2)",marginBottom:14,paddingBottom:10,borderBottom:"1px solid var(-b)",textTransform:"uppercase",letterSpacing:"1.2px"}}>{title}</p><div style={{display:"flex",flexDirection:"column",gap:14}}>{children}</div></Card>;
const Row=({l,sub,end})=><div style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:14}}><div style={{flex:1}}><p style={{fontSize:13,color:"var(-t1)",fontWeight:500}}>{l}</p>{sub&&<p style={{fontSize:11,color:"var(-t3)",marginTop:2}}>{sub}</p>}</div><div style={{flexShrink:0}}>{end}</div></div>;

const planObj = PLANS.find(p=>p.id===(user?.plan||"free"))||PLANS[0];

return (
<div className="aFU" style={{display:"flex",flexDirection:"column",gap:14}}>
<SHd title={tr.settings} sub="Personalize your experience"/>

  {/* Plan card */}
  <Card style={{padding:"16px 20px",border:`1px solid ${planObj.color}44`,background:`${planObj.color}08`}}>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:12}}>
      <div>
        <p style={{fontSize:10,color:"var(--t2)",fontWeight:700,textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>{tr.currentPlan}</p>
        <p style={{fontSize:18,fontWeight:900,color:planObj.color}}>{planObj.label}</p>
        <p style={{fontSize:12,color:"var(--t2)",marginTop:2}}>{planObj.period==="forever"?"Free forever":money(planObj.priceXAF,"XAF")+"/mo"}</p>
      </div>
      <Btn sz="sm" onClick={()=>{}}>⬆ {tr.upgradeNow}</Btn>
    </div>
  </Card>

  {/* Themes */}
  <Card>
    <p style={{fontSize:10.5,fontWeight:800,color:"var(--t2)",marginBottom:14,textTransform:"uppercase",letterSpacing:"1.2px"}}>{tr.theme}</p>
    <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
      {Object.entries(THEMES).map(([id,t])=>(
        <button key={id} onClick={()=>setTheme(id)} style={{display:"flex",alignItems:"center",gap:7,padding:"8px 14px",borderRadius:9,border:"2px solid "+(theme===id?"var(--ac)":"var(--bH)"),background:theme===id?"rgba(var(--ar),.1)":"var(--c)",color:theme===id?"var(--ac)":"var(--t2)",cursor:"pointer",transition:"all .2s",fontSize:12,fontWeight:700}}>
          {t.g} {t.n}{theme===id&&<span style={{width:5,height:5,borderRadius:"50%",background:"var(--ac)",flexShrink:0}}/>}
        </button>
      ))}
    </div>
  </Card>

  {/* Language */}
  <Card>
    <p style={{fontSize:10.5,fontWeight:800,color:"var(--t2)",marginBottom:14,textTransform:"uppercase",letterSpacing:"1.2px"}}>{tr.language}</p>
    <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
      {[["en","English 🇬🇧"],["fr","Français 🇫🇷"],["es","Español 🇪🇸"],["sw","Kiswahili 🇰🇪"],["pt","Português 🇧🇷"],["de","Deutsch 🇩🇪"]].map(([id,l])=>(
        <button key={id} onClick={()=>setLang(id)} style={{padding:"7px 13px",borderRadius:9,fontSize:12,fontWeight:700,border:"2px solid "+(lang===id?"var(--ac)":"var(--bH)"),background:lang===id?"rgba(var(--ar),.1)":"var(--c)",color:lang===id?"var(--ac)":"var(--t2)",cursor:"pointer",transition:"all .2s"}}>{l}</button>
      ))}
    </div>
  </Card>

  {/* Currency */}
  <Card>
    <p style={{fontSize:10.5,fontWeight:800,color:"var(--t2)",marginBottom:14,textTransform:"uppercase",letterSpacing:"1.2px"}}>{tr.currency}</p>
    <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
      {Object.entries(CURRENCIES).map(([code,c])=>(
        <button key={code} onClick={()=>setCur(code)} style={{padding:"7px 13px",borderRadius:9,fontSize:12,fontWeight:700,border:"2px solid "+(cur===code?"var(--ac)":"var(--bH)"),background:cur===code?"rgba(var(--ar),.1)":"var(--c)",color:cur===code?"var(--ac)":"var(--t2)",cursor:"pointer",transition:"all .2s"}}>{c.s} {code}</button>
      ))}
    </div>
  </Card>

  <Sec title="Experience">
    <Row l={tr.sounds} sub="Clicks, alerts & transitions" end={<Toggle on={soundOn} toggle={()=>setSoundOn(!soundOn)}/>}/>
    <Row l={tr.animations} sub="Page transitions & effects" end={<Toggle on={animOn} toggle={()=>setAnimOn(!animOn)}/>}/>
  </Sec>
  <Sec title="Business Profile">
    <Row l={tr.businessName} end={<input value={cfg.bizName} onChange={e=>setCfg({...cfg,bizName:e.target.value})} style={{width:220}}/>}/>
    <Row l={tr.timezone} end={<select value={cfg.tz} onChange={e=>setCfg({...cfg,tz:e.target.value})} style={{width:220}}>{["Africa/Douala","Africa/Lagos","Africa/Nairobi","Africa/Johannesburg","Europe/Paris","UTC","America/New_York"].map(t=><option key={t}>{t}</option>)}</select>}/>
  </Sec>
  <Sec title={tr.notifications}>
    <Row l={tr.emailNotifs} sub="Renewals, payments & alerts" end={<Toggle on={cfg.email} toggle={()=>setCfg({...cfg,email:!cfg.email})}/>}/>
    <Row l={tr.smsAlerts} sub="Critical events via SMS" end={<Toggle on={cfg.sms} toggle={()=>setCfg({...cfg,sms:!cfg.sms})}/>}/>
  </Sec>
  <Sec title={tr.security}>
    <Row l={tr.twoFA} sub="Extra login protection" end={<Toggle on={cfg.twofa} toggle={()=>setCfg({...cfg,twofa:!cfg.twofa})}/>}/>
    <Row l={tr.autoBackup} sub="Daily automated backups" end={<Toggle on={cfg.backup} toggle={()=>setCfg({...cfg,backup:!cfg.backup})}/>}/>
  </Sec>

  <Card style={{textAlign:"center",padding:22}}>
    <div style={{width:48,height:48,borderRadius:14,margin:"0 auto 14px",background:"linear-gradient(135deg,var(--ac),var(--ac2))",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,boxShadow:"0 8px 24px rgba(var(--ar),.35)"}}>⬡</div>
    <p style={{fontSize:15,fontWeight:900,color:"var(--ac)",marginBottom:3}}>Lekoev BOS v4.0</p>
    <p style={{fontSize:12,color:"var(--t2)",marginBottom:2,fontWeight:600}}>{tr.by}</p>
    <p style={{fontSize:11,color:"var(--t3)",marginBottom:14}}>{tr.copy}</p>
    <div style={{display:"flex",justifyContent:"center",gap:7,flexWrap:"wrap"}}><Badge c="ac">Licensed Software</Badge><Badge c="ok">AI-Powered</Badge><Badge c="pu">Multi-tenant</Badge><Badge c="gd">OHADA Compliant</Badge></div>
  </Card>

  <div style={{display:"flex",gap:8}}><Btn>{tr.saveChanges}</Btn><Btn v="er">Reset</Btn></div>
</div>

);
};

// ═════════════════════════════════════════════════════════════════════════════
// MAIN APP SHELL
// ═════════════════════════════════════════════════════════════════════════════
const NAV = [
{id:"dashboard",   icon:"◉"},
{id:"transactions",icon:"⇅"},
{id:"clients",     icon:"◈"},
{id:"invoices",    icon:"📄"},
{id:"inventory",   icon:"📦"},
{id:"payroll",     icon:"💼"},
{id:"reports",     icon:"▤"},
null,
{id:"ai",          icon:"✦",badge:"AI"},
{id:"passkeys",    icon:"🔑",label:"Passkey Gen"},
{id:"settings",    icon:"⚙"},
];

const PAGES = {
dashboard:Dashboard, transactions:TxPage, clients:ClientsPage,
invoices:InvoicesPage, inventory:InventoryPage, payroll:PayrollPage,
reports:ReportsPage, ai:AIPage, passkeys:PasskeyPage, settings:SettingsPage,
};

const NOTIFS = [
{icon:"⚠️",txt:"Mini Supermarche trial ends in 17 days",time:"now",c:"wn"},
{icon:"💰",txt:"Payment received - OHADA Pro",           time:"2h", c:"ok"},
{icon:"🔑",txt:"New device - Pharmacie Centrale",        time:"5h", c:"ac"},
{icon:"📊",txt:"Monthly report ready",                   time:"1d", c:"def"},
];

const AppShell = ({user, onLogout}) => {
const {tr, theme, setTheme, lang, setLang, cur, setCur, soundOn, setSoundOn, animOn, setAnimOn, setPage: setPageCtx} = useApp();
const [page,setPageRaw] = useState("dashboard");
const [pageKey,setPageKey] = useState(0);
const [sideOpen,setSide] = useState(true);
const [mobSide,setMobSide] = useState(false);
const [notifOpen,setNotif] = useState(false);
const [mobile,setMobile] = useState(false);

useEffect(()=>{ const chk=()=>setMobile(window.innerWidth<768); chk(); window.addEventListener("resize",chk); return()=>window.removeEventListener("resize",chk); },[]);
useEffect(()=>{ if(mobile) setSide(false); },[mobile]);

// Wire up context setPage
const nav = p => { setPageRaw(p); setPageKey(k=>k+1); if(mobile) setMobSide(false); if(soundOn) SFX.tap(); };

// Override context setPage
useEffect(()=>{ if(setPageCtx) setPageCtx.__override = nav; },[]);

const CurPage = PAGES[page]||Dashboard;

return (
<div style={{display:"flex",height:"100vh",overflow:"hidden",background:"var(-bg)"}}>
{mobile&&mobSide&&<div onClick={()=>setMobSide(false)} className="aFI" style={{position:"fixed",inset:0,background:"rgba(0,0,0,.55)",zIndex:150}}/>}

  {/* SIDEBAR */}
  <div style={{position:mobile?"fixed":"relative",top:0,bottom:0,left:0,zIndex:200,width:220,minWidth:220,transform:mobile?(mobSide?"translateX(0)":"translateX(-220px)"):(sideOpen?"translateX(0)":"translateX(-220px)"),transition:"transform .3s cubic-bezier(.22,1,.36,1)",background:"var(--p)",borderRight:"1px solid var(--b)",display:"flex",flexDirection:"column",overflow:"hidden",flexShrink:0}}>
    {/* Logo */}
    <div style={{padding:"15px 16px 12px",borderBottom:"1px solid var(--b)",flexShrink:0}}>
      <div style={{display:"flex",alignItems:"center",gap:10}}>
        <div style={{width:32,height:32,borderRadius:9,flexShrink:0,background:"linear-gradient(145deg,var(--ac),var(--ac2))",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,animation:"glowP 4s ease infinite"}}>⬡</div>
        <div><p style={{fontSize:13.5,fontWeight:900,color:"var(--t1)",lineHeight:1}}>Lekoev.BOS</p><p style={{fontSize:8,color:"var(--t3)",marginTop:2,textTransform:"uppercase",letterSpacing:"1.5px",fontWeight:700}}>by Likafi Jr</p></div>
      </div>
    </div>

    {/* User / Plan */}
    <div style={{margin:"10px 10px 0",padding:"9px 12px",background:"var(--c)",borderRadius:9,border:"1px solid var(--b)",flexShrink:0}}>
      <p style={{fontSize:8,color:"var(--t3)",textTransform:"uppercase",letterSpacing:1,marginBottom:2,fontWeight:700}}>Workspace</p>
      <p style={{fontSize:12,fontWeight:700,color:"var(--t1)",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{user?.biz||"My Business"}</p>
      <div style={{display:"flex",alignItems:"center",gap:5,marginTop:3}}>
        <Badge c={user?.plan==="enterprise"?"pu":user?.plan==="business"?"gd":"ac"} sz="xs">{(user?.plan||"FREE").toUpperCase()}</Badge>
        <span style={{fontSize:9,color:"var(--t3)"}}>{user?.cur||"XAF"} · {user?.country||"Africa"}</span>
      </div>
    </div>

    {/* Nav */}
    <nav style={{flex:1,padding:"8px 7px",overflowY:"auto",display:"flex",flexDirection:"column",gap:1}}>
      {NAV.map((item,i)=>item===null?<div key={i} style={{margin:"4px 4px",borderTop:"1px solid var(--b)"}}/>:(
        <button key={item.id} onClick={()=>nav(item.id)} style={{display:"flex",alignItems:"center",gap:8,padding:"8px 10px",borderRadius:8,border:"none",cursor:"pointer",textAlign:"left",width:"100%",background:page===item.id?"rgba(var(--ar),.12)":"transparent",color:page===item.id?"var(--ac)":"var(--t2)",borderLeft:page===item.id?"2.5px solid var(--ac)":"2.5px solid transparent",transition:"all .15s",fontWeight:page===item.id?700:400,fontSize:12.5}}
          onMouseEnter={e=>{if(page!==item.id){e.currentTarget.style.background="var(--c)";e.currentTarget.style.color="var(--t1)";}}}
          onMouseLeave={e=>{if(page!==item.id){e.currentTarget.style.background="transparent";e.currentTarget.style.color="var(--t2)";}}}
        >
          <span style={{fontSize:12.5,width:16,textAlign:"center",flexShrink:0}}>{item.icon}</span>
          <span style={{flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{item.label||tr[item.id]||item.id}</span>
          {item.badge&&<Badge c="ac" sz="xs">{item.badge}</Badge>}
        </button>
      ))}
    </nav>

    {/* User row */}
    <div style={{padding:"10px 12px",borderTop:"1px solid var(--b)",flexShrink:0}}>
      <div style={{display:"flex",alignItems:"center",gap:8}}>
        <div style={{width:30,height:30,borderRadius:"50%",flexShrink:0,background:"rgba(var(--ar),.12)",border:"1.5px solid rgba(var(--ar),.3)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:900,color:"var(--ac)"}}>{(user?.name||"L").slice(0,2).toUpperCase()}</div>
        <div style={{flex:1,minWidth:0}}><p style={{fontSize:12,fontWeight:700,color:"var(--t1)",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{user?.name||"Likafi Jr"}</p><p style={{fontSize:9,color:"var(--t3)"}}>Admin</p></div>
        <button onClick={onLogout} title={tr.logout} style={{background:"none",border:"1px solid var(--b)",borderRadius:6,padding:"3px 7px",color:"var(--t3)",cursor:"pointer",fontSize:11,transition:"all .15s"}} onMouseEnter={e=>{e.target.style.color="var(--er)";e.target.style.borderColor="var(--er)";}} onMouseLeave={e=>{e.target.style.color="var(--t3)";e.target.style.borderColor="var(--b)";}}>⎋</button>
      </div>
    </div>
  </div>

  {/* MAIN */}
  <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden",minWidth:0,transition:"margin-left .3s cubic-bezier(.22,1,.36,1)",marginLeft:!mobile&&!sideOpen?"-220px":"0"}}>
    {/* Topbar */}
    <div style={{height:50,background:"var(--p)",borderBottom:"1px solid var(--b)",display:"flex",alignItems:"center",padding:"0 14px",gap:10,flexShrink:0}}>
      <button onClick={()=>mobile?setMobSide(!mobSide):setSide(!sideOpen)} style={{background:"none",border:"1px solid var(--bH)",borderRadius:7,padding:"5px 9px",color:"var(--t2)",cursor:"pointer",fontSize:13,transition:"all .15s",flexShrink:0}} onMouseEnter={e=>{e.target.style.color="var(--ac)";e.target.style.borderColor="var(--ac)";}} onMouseLeave={e=>{e.target.style.color="var(--t2)";e.target.style.borderColor="var(--bH)";}}>☰</button>

      <div style={{flex:1,maxWidth:300,position:"relative"}}>
        <span style={{position:"absolute",left:10,top:"50%",transform:"translateY(-50%)",color:"var(--t3)",fontSize:12,pointerEvents:"none"}}>⌕</span>
        <input placeholder={tr.search} style={{paddingLeft:28,height:32,fontSize:12}}/>
      </div>

      <div style={{flex:1}}/>

      <div style={{display:"flex",alignItems:"center",gap:8,flexShrink:0}}>
        <LiveDot className="mh"/>

        <button onClick={()=>setSoundOn(!soundOn)} title={tr.sounds} style={{background:"none",border:"1px solid var(--bH)",borderRadius:7,padding:"5px 9px",color:soundOn?"var(--ac)":"var(--t2)",cursor:"pointer",fontSize:12,transition:"all .15s"}}>{soundOn?"🔊":"🔇"}</button>

        <button onClick={()=>{const ids=Object.keys(THEMES);setTheme(ids[(ids.indexOf(theme)+1)%ids.length]);}} title="Cycle theme" style={{background:"none",border:"1px solid var(--bH)",borderRadius:7,padding:"5px 9px",color:"var(--t2)",cursor:"pointer",fontSize:13,transition:"all .15s"}} onMouseEnter={e=>{e.target.style.color="var(--ac)";e.target.style.borderColor="var(--ac)";}} onMouseLeave={e=>{e.target.style.color="var(--t2)";e.target.style.borderColor="var(--bH)";}}>
          {THEMES[theme].g}
        </button>

        <div style={{position:"relative"}}>
          <button onClick={()=>{setNotif(!notifOpen);if(soundOn)SFX.notify();}} style={{background:"none",border:"1px solid var(--bH)",borderRadius:7,padding:"5px 9px",color:"var(--t2)",cursor:"pointer",fontSize:13,transition:"all .15s",position:"relative"}} onMouseEnter={e=>{e.target.style.color="var(--ac)";e.target.style.borderColor="var(--ac)";}} onMouseLeave={e=>{e.target.style.color="var(--t2)";e.target.style.borderColor="var(--bH)";}}>
            🔔<span style={{position:"absolute",top:-2,right:-2,width:8,height:8,borderRadius:"50%",background:"var(--er)",border:"2px solid var(--p)"}}/>
          </button>
          {notifOpen&&<div className="aSI" style={{position:"absolute",top:44,right:0,width:290,background:"var(--c)",border:"1px solid var(--bH)",borderRadius:14,boxShadow:"0 24px 70px rgba(0,0,0,.5)",zIndex:999,overflow:"hidden"}}>
            <div style={{padding:"11px 15px",borderBottom:"1px solid var(--b)",display:"flex",justifyContent:"space-between",alignItems:"center"}}><p style={{fontSize:13,fontWeight:700,color:"var(--t1)"}}>{tr.notifications}</p><button onClick={()=>setNotif(false)} style={{background:"none",border:"none",color:"var(--t3)",cursor:"pointer",fontSize:14,lineHeight:1}}>✕</button></div>
            {NOTIFS.map((n,i)=><div key={i} style={{padding:"10px 15px",display:"flex",gap:9,cursor:"pointer",transition:"background .13s",borderBottom:"1px solid var(--b)"}} onMouseEnter={e=>e.currentTarget.style.background="var(--cH)"} onMouseLeave={e=>e.currentTarget.style.background=""}><span style={{fontSize:15,flexShrink:0}}>{n.icon}</span><div><p style={{fontSize:12,color:"var(--t1)",lineHeight:1.4}}>{n.txt}</p><p style={{fontSize:10,color:"var(--t3)",marginTop:2}}>{n.time}</p></div></div>)}
          </div>}
        </div>

        <Badge c={user?.plan==="enterprise"?"pu":user?.plan==="business"?"gd":"ac"} className="mh">{(user?.plan||"FREE").toUpperCase()}</Badge>
      </div>
    </div>

    {/* Mobile bottom nav */}
    {mobile&&<div style={{position:"fixed",bottom:0,left:0,right:0,height:54,background:"var(--p)",borderTop:"1px solid var(--b)",display:"flex",alignItems:"center",justifyContent:"space-around",zIndex:100,padding:"0 6px"}}>
      {[{id:"dashboard",icon:"◉"},{id:"transactions",icon:"⇅"},{id:"clients",icon:"◈"},{id:"ai",icon:"✦"},{id:"settings",icon:"⚙"}].map(item=>(
        <button key={item.id} onClick={()=>nav(item.id)} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:3,padding:"6px 10px",background:"none",border:"none",cursor:"pointer",color:page===item.id?"var(--ac)":"var(--t3)",transition:"color .15s",flex:1}}>
          <span style={{fontSize:17,lineHeight:1}}>{item.icon}</span>
          <span style={{fontSize:8,fontWeight:700,textTransform:"uppercase",letterSpacing:".5px"}}>{(tr[item.id]||item.id).slice(0,5)}</span>
        </button>
      ))}
    </div>}

    {/* Page */}
    <div style={{flex:1,overflowY:"auto",padding:mobile?"14px 14px 68px":"22px 24px 28px"}}>
      <div key={pageKey}><CurPage user={user}/></div>
    </div>
  </div>

  {/* Watermark */}
  <div style={{position:"fixed",bottom:mobile?62:10,right:12,fontSize:9,color:"var(--t3)",opacity:.35,pointerEvents:"none",fontWeight:700,letterSpacing:".5px",fontFamily:"'DM Mono',monospace",zIndex:10,textTransform:"uppercase"}}>
    Lekoev.BOS · Likafi Jr © 2026
  </div>
</div>

);
};

// ═════════════════════════════════════════════════════════════════════════════
// ROOT - State machine: landing → onboarding | signin → welcome → app
// ═════════════════════════════════════════════════════════════════════════════
function App() {
const [screen,setScreen] = useState("landing"); // landing | onboarding | signin | welcome | app
const [initPlan,setInitPlan] = useState("pro");
const [user,setUser] = useState(null);
const [theme,setThemeRaw] = useState("void");
const [lang,setLang] = useState("en");
const [cur,setCur] = useState("XAF");
const [soundOn,setSoundOn] = useState(true);
const [animOn,setAnimOn] = useState(true);

const setTheme = id => { setThemeRaw(id); applyTheme(id); if(soundOn) SFX.whoosh(); };
useEffect(()=>applyTheme(theme),[]);

const tr = LANG[lang]||LANG.en;

// Context setPage - shell will override
const ctxSetPage = (p) => {}; // shell overrides this

const ctx = useMemo(()=>({
tr,theme,setTheme,lang,setLang,cur,setCur,soundOn,setSoundOn,animOn,setAnimOn,
setPage:ctxSetPage,
}),[tr,theme,lang,cur,soundOn,animOn]);

const goStart = (planId="pro") => { setInitPlan(planId||"pro"); setScreen("onboarding"); };
const goSignin = () => setScreen("signin");
const goLanding = () => setScreen("landing");

const handleOnboardingComplete = (form) => {
setUser({ name:form.name, email:form.email, biz:form.bizName, plan:form.plan, cur:form.currency, country:form.country, city:form.city, isNew:true });
setCur(form.currency);
setScreen("welcome");
};

const handleSigninComplete = (userData) => {
setUser(userData);
if(userData.cur) setCur(userData.cur);
setScreen("welcome");
};

const handleWelcomeDone = () => setScreen("app");
const handleLogout = () => { setUser(null); setScreen("landing"); };

return (
<Ctx.Provider value={ctx}>
<GStyle/>
{screen==="landing" && <Landing onStart={goStart} onSignin={goSignin}/>}
{screen==="onboarding" && <Onboarding initialPlan={initPlan} onComplete={handleOnboardingComplete}/>}
{screen==="signin" && <SignIn onLogin={handleSigninComplete} onBack={goLanding}/>}
{screen==="welcome" && <WelcomeAnim user={user?.name||"there"} biz={user?.biz||"Lekoev BOS"} onDone={handleWelcomeDone} soundOn={soundOn}/>}
{screen==="app" && <AppShell user={user} onLogout={handleLogout}/>}
</Ctx.Provider>
);
}

export default App;
