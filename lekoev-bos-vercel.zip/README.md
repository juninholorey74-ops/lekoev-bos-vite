# Lekoev BOS v4.0

**The Business Operating System Built for Africa**

A premium, futuristic React + Vite application featuring AI-powered business management, multi-tenant support, and comprehensive accounting, invoicing, payroll, and inventory management.

## Features

- **7 Premium Themes**: Void, Aurora, Ember, Royal, Noir, Ice, Carbon
- **6 Languages**: English, French, Spanish, Portuguese, and more
- **AI Assistant**: Integrated AI panel for business insights
- **Multi-Module System**: Dashboard, Transactions, Clients, Invoices, Inventory, Payroll, Reports
- **Licensing System**: Passkey generation and device management
- **Advanced Settings**: Theme switching, language selection, notifications, security, and more
- **Responsive Design**: Mobile-first, fully responsive interface
- **Sound Effects**: Interactive audio feedback system
- **Animations**: Smooth, professional animations throughout

## Tech Stack

- **Frontend**: React 18.3.1 + Vite 5.4.2
- **Styling**: CSS-in-JS with CSS variables for theming
- **Build**: Vite with React plugin

## Project Structure

```
├── src/
│   ├── App.jsx          # Main application component
│   ├── main.jsx         # React entry point
│   └── index.css        # Global styles
├── index.html           # HTML entry point
├── vite.config.js       # Vite configuration
└── package.json         # Dependencies
```

## Installation

```bash
npm install
```

## Development

```bash
npm run dev
```

The dev server will start at `http://localhost:5173`

## Build

```bash
npm run build
```

Output will be in the `dist/` directory.

## Preview

```bash
npm run preview
```

## Key Fixes Applied

1. **Removed markdown code blocks** (``` and ```jsx) that were corrupting JSX syntax
2. **Fixed duplicate default exports** - Removed redundant `export default App` statement
3. **Replaced smart quotes** with proper JavaScript quotes throughout the codebase
4. **Verified all JSX syntax** - All components, inline styles, and spread operators are valid

## Themes

- **Void** - Deep blue, futuristic
- **Aurora** - Green, nature-inspired
- **Ember** - Orange, warm
- **Royal** - Purple, elegant
- **Noir** - Monochrome, minimal
- **Ice** - Light, clean
- **Carbon** - Steel blue, professional

## Languages

- English (en)
- French (fr)
- Spanish (es)
- Portuguese (pt)

## License

© 2026 Lekoev Enterprises. All Rights Reserved.

Created by Likafi Jr
