# Deployment Instructions for Lekoev BOS v4.0

## Option 1: Deploy via GitHub + Vercel (Recommended)

### Step 1: Create a GitHub Repository

1. Go to [GitHub.com](https://github.com)
2. Click **"New"** to create a new repository
3. Name it: `lekoev-bos-vite`
4. Choose **Public** or **Private**
5. Click **"Create repository"**

### Step 2: Push Code to GitHub

Copy and paste these commands in your terminal:

```bash
cd /home/ubuntu/project/lekoev-bos
git remote add origin https://github.com/YOUR_USERNAME/lekoev-bos-vite.git
git branch -M main
git push -u origin main
```

Replace `YOUR_USERNAME` with your actual GitHub username.

When prompted, use:
- **Username**: Your GitHub username
- **Password**: Your GitHub Personal Access Token (not your password)

### Step 3: Create a Personal Access Token (if needed)

1. Go to GitHub.com → **Settings** → **Developer settings** → **Personal access tokens** → **Tokens (classic)**
2. Click **"Generate new token"**
3. Give it a name: `Vercel Deployment`
4. Select scopes: `repo` (full control of private repositories)
5. Click **"Generate token"**
6. Copy the token and use it as your password when pushing to GitHub

### Step 4: Deploy to Vercel

1. Go to [Vercel.com](https://vercel.com)
2. Click **"New Project"**
3. Click **"Import Git Repository"**
4. Paste your GitHub repository URL: `https://github.com/YOUR_USERNAME/lekoev-bos-vite`
5. Click **"Import"**
6. Vercel will auto-detect Vite configuration
7. Click **"Deploy"**

Your site will be live at: `https://lekoev-bos-vite.vercel.app` (or your custom domain)

---

## Option 2: Direct Vercel Deployment (Without GitHub)

1. Go to [Vercel.com](https://vercel.com)
2. Click **"New Project"**
3. Click **"Upload Project"** (or drag & drop the project folder)
4. Select the `lekoev-bos` folder
5. Vercel will auto-detect Vite
6. Click **"Deploy"**

---

## Build Verification

The project has been successfully built with:
- ✅ Zero syntax errors
- ✅ Zero JSX errors
- ✅ All dependencies resolved
- ✅ Production bundle: 530 KB (minified)
- ✅ Gzipped: 138 KB

## Project Details

- **Framework**: React 18.3.1 + Vite 5.4.2
- **Build Output**: `dist/` directory
- **Entry Point**: `index.html`
- **Node Version**: 18+ recommended

## Environment Variables (if needed)

The project doesn't require any environment variables for basic deployment. If you need to add custom configuration, create a `.env.production` file in the root directory.

---

## Troubleshooting

### "Build failed on Vercel"
- Ensure Node version is 18+
- Check that all dependencies are in `package.json`
- Verify `vite.config.js` is correct

### "White screen on load"
- Check browser console for errors (F12)
- Verify all assets loaded correctly
- Clear browser cache (Ctrl+Shift+Delete)

### "Cannot find module"
- Run `npm install` locally
- Verify all imports use correct paths
- Check that no files are missing

---

## Support

For questions about:
- **GitHub**: Visit [GitHub Docs](https://docs.github.com)
- **Vercel**: Visit [Vercel Docs](https://vercel.com/docs)
- **Vite**: Visit [Vite Docs](https://vitejs.dev)

